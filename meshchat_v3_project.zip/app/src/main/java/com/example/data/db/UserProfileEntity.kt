package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey
    val userId: String = "local_user_1",
    val name: String = "Mesh Traveler",
    val statusMessage: String = "Offline Mesh Ready",
    val avatarColorHex: String = "#0284C7",
    val meshNodeId: String = "NODE-8821",
    val isRelayEnabled: Boolean = true,
    val autoConnectBonded: Boolean = true
)
