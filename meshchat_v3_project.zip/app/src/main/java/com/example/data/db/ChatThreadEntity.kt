package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_threads")
data class ChatThreadEntity(
    @PrimaryKey
    val threadId: String,
    val peerId: String,
    val title: String,
    val avatarColorHex: String = "#3B82F6",
    val lastMessageText: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isBroadcastThread: Boolean = false,
    val isPinned: Boolean = false
)
