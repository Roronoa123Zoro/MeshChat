package com.example.data.nearby

import android.content.Context
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream
import java.util.Collections

/**
 * Peer model representing a verified connected or discovered nearby device.
 */
data class Peer(
    val endpointId: String,
    val endpointName: String,
    val distanceMeters: Float = (10..50).random().toFloat(),
    val isConnected: Boolean = true,
    val connectionTime: Long = System.currentTimeMillis()
)

/**
 * Real-time transfer progress model for file and sketch transfers.
 */
data class TransferProgress(
    val payloadId: Long,
    val bytesTransferred: Long,
    val totalBytes: Long,
    val progressPercentage: Int
)

/**
 * Incoming payload wrapper to deliver received bytes or files to upper layers (Repository/Room).
 */
sealed class IncomingPayload {
    data class BytesPayload(
        val endpointId: String,
        val bytes: ByteArray,
        val timestamp: Long = System.currentTimeMillis()
    ) : IncomingPayload()

    data class FilePayload(
        val endpointId: String,
        val payloadId: Long,
        val file: File,
        val fileName: String?,
        val timestamp: Long = System.currentTimeMillis()
    ) : IncomingPayload()

    data class StreamPayload(
        val endpointId: String,
        val payloadId: Long,
        val stream: InputStream,
        val timestamp: Long = System.currentTimeMillis()
    ) : IncomingPayload()
}

/**
 * Production-ready NearbyConnectionManager utilizing Google Nearby Connections API with Strategy.P2P_CLUSTER.
 * Enforces strict Service ID filtering, programmatic background auto-connection without OS pairing popups,
 * and an app-level protocol handshake (HANDSHAKE_VERIFY / ACK) to reject non-MeshChat devices.
 */
class NearbyConnectionManager(
    private val context: Context,
    private val connectionsClient: ConnectionsClient = Nearby.getConnectionsClient(context)
) {
    companion object {
        private const val TAG = "NearbyConnectionManager"
        const val SERVICE_ID = "com.example.meshchat.p2p"
        private const val MAX_RETRY_ATTEMPTS = 3

        // App-Level Handshake Constants
        private const val HANDSHAKE_APP_ID = "MESHCHAT_V1"
        private const val HANDSHAKE_ACK_ID = "MESHCHAT_V1_ACK"
        private val HANDSHAKE_VERIFY_BYTES = byteArrayOf(0x01.toByte()) + HANDSHAKE_APP_ID.toByteArray(Charsets.UTF_8)
        private val HANDSHAKE_ACK_BYTES = byteArrayOf(0x02.toByte()) + HANDSHAKE_ACK_ID.toByteArray(Charsets.UTF_8)
        private const val HANDSHAKE_TIMEOUT_MS = 2000L
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Local device username/node label
    private var localEndpointName: String = android.os.Build.MODEL.ifBlank { "Mesh Node" }

    // State Flows
    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val _connectedPeers = MutableStateFlow<List<Peer>>(emptyList())
    val connectedPeers: StateFlow<List<Peer>> = _connectedPeers.asStateFlow()

    private val _discoveredEndpoints = MutableStateFlow<Map<String, String>>(emptyMap())
    val discoveredEndpoints: StateFlow<Map<String, String>> = _discoveredEndpoints.asStateFlow()

    // Shared Flow for Incoming Payloads (Text/JSON, SOS, Canvas Sketches & Heavy Files)
    private val _incomingPayloads = MutableSharedFlow<IncomingPayload>(extraBufferCapacity = 64)
    val incomingPayloads: SharedFlow<IncomingPayload> = _incomingPayloads.asSharedFlow()

    // Shared Flow for Real-Time Transfer Progress Updates (0 to 100%)
    private val _payloadProgress = MutableSharedFlow<TransferProgress>(extraBufferCapacity = 64)
    val payloadProgress: SharedFlow<TransferProgress> = _payloadProgress.asSharedFlow()

    // Set of endpoints that have successfully passed the MeshChat handshake
    private val verifiedEndpoints = Collections.synchronizedSet(mutableSetOf<String>())

    // Pending handshake timeout jobs map
    private val pendingHandshakes = Collections.synchronizedMap(mutableMapOf<String, Job>())

    // Map of pending incoming file payloads by payload ID
    private val incomingFilePayloads = mutableMapOf<Long, Pair<String, File>>()

    // Map to track retry attempts for endpoints
    private val retryCounts = mutableMapOf<String, Int>()

    /**
     * Start Advertising this device to surrounding peers using Strategy.P2P_CLUSTER and strict SERVICE_ID.
     */
    fun startAdvertising(displayName: String = localEndpointName) {
        localEndpointName = displayName
        val advertisingOptions = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()

        connectionsClient.startAdvertising(
            displayName,
            SERVICE_ID,
            connectionLifecycleCallback,
            advertisingOptions
        ).addOnSuccessListener {
            Log.d(TAG, "Advertising started successfully as $displayName with SERVICE_ID: $SERVICE_ID")
            _isAdvertising.value = true
        }.addOnFailureListener { e ->
            Log.e(TAG, "Failed to start advertising: ${e.message}", e)
            _isAdvertising.value = false
        }
    }

    /**
     * Stop Advertising.
     */
    fun stopAdvertising() {
        connectionsClient.stopAdvertising()
        _isAdvertising.value = false
        Log.d(TAG, "Advertising stopped")
    }

    /**
     * Start Discovering surrounding peers using Strategy.P2P_CLUSTER and strict SERVICE_ID.
     */
    fun startDiscovery() {
        val discoveryOptions = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()

        connectionsClient.startDiscovery(
            SERVICE_ID,
            endpointDiscoveryCallback,
            discoveryOptions
        ).addOnSuccessListener {
            Log.d(TAG, "Discovery started successfully for SERVICE_ID: $SERVICE_ID")
            _isDiscovering.value = true
        }.addOnFailureListener { e ->
            Log.e(TAG, "Failed to start discovery: ${e.message}", e)
            _isDiscovering.value = false
        }
    }

    /**
     * Stop Discovery.
     */
    fun stopDiscovery() {
        connectionsClient.stopDiscovery()
        _isDiscovering.value = false
        Log.d(TAG, "Discovery stopped")
    }

    /**
     * Stop advertising, discovery, and disconnect all active connections.
     */
    fun stopAll() {
        stopAdvertising()
        stopDiscovery()
        disconnectAll()
        Log.d(TAG, "Stopped all advertising, discovery, and endpoints")
    }

    /**
     * Initiate connection request to a discovered endpoint programmatically.
     */
    fun requestConnection(endpointId: String, endpointName: String) {
        connectionsClient.requestConnection(
            localEndpointName,
            endpointId,
            connectionLifecycleCallback
        ).addOnSuccessListener {
            Log.d(TAG, "Programmatically requested connection to $endpointName ($endpointId)")
        }.addOnFailureListener { e ->
            Log.e(TAG, "Failed to request connection to $endpointName ($endpointId): ${e.message}", e)
        }
    }

    /**
     * Callback for connection lifecycle events (initiation, result, disconnection).
     */
    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            Log.d(TAG, "Connection initiated with ${info.endpointName} ($endpointId). Auto-accepting programmatically...")
            _discoveredEndpoints.value = _discoveredEndpoints.value + (endpointId to info.endpointName)
            // Programmatically accept connection without user intervention or OS pairing popups
            connectionsClient.acceptConnection(endpointId, payloadCallback)
                .addOnSuccessListener {
                    Log.d(TAG, "Accepted connection from ${info.endpointName} ($endpointId)")
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Error accepting connection from $endpointId: ${e.message}", e)
                }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            when (result.status.statusCode) {
                ConnectionsStatusCodes.STATUS_OK -> {
                    val endpointName = _discoveredEndpoints.value[endpointId] ?: "Nearby Peer"
                    Log.i(TAG, "Connected at transport level to endpoint: $endpointName ($endpointId). Initiating HANDSHAKE_VERIFY...")
                    retryCounts.remove(endpointId)

                    // Send App-Level Protocol Handshake
                    val verifyPayload = Payload.fromBytes(HANDSHAKE_VERIFY_BYTES)
                    connectionsClient.sendPayload(endpointId, verifyPayload)
                        .addOnFailureListener { e ->
                            Log.e(TAG, "Failed to send HANDSHAKE_VERIFY to $endpointId: ${e.message}")
                            connectionsClient.disconnectFromEndpoint(endpointId)
                        }

                    // Enforce 2-second Handshake Verification Timeout Window
                    val timeoutJob = scope.launch {
                        delay(HANDSHAKE_TIMEOUT_MS)
                        if (!verifiedEndpoints.contains(endpointId)) {
                            Log.w(TAG, "REJECTED: Endpoint $endpointId failed MeshChat protocol handshake within 2s timeout. Disconnecting non-MeshChat device.")
                            pendingHandshakes.remove(endpointId)
                            connectionsClient.disconnectFromEndpoint(endpointId)
                            _connectedPeers.value = _connectedPeers.value.filter { it.endpointId != endpointId }
                        }
                    }
                    pendingHandshakes[endpointId]?.cancel()
                    pendingHandshakes[endpointId] = timeoutJob
                }
                ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED -> {
                    Log.w(TAG, "Connection rejected by endpoint $endpointId")
                }
                ConnectionsStatusCodes.STATUS_ERROR -> {
                    Log.e(TAG, "Connection failed to endpoint $endpointId with status ERROR")
                    handleConnectionFailure(endpointId)
                }
                else -> {
                    Log.w(TAG, "Connection result for $endpointId: ${result.status.statusCode}")
                }
            }
        }

        override fun onDisconnected(endpointId: String) {
            Log.i(TAG, "Disconnected from endpoint: $endpointId")
            verifiedEndpoints.remove(endpointId)
            pendingHandshakes.remove(endpointId)?.cancel()
            _connectedPeers.value = _connectedPeers.value.filter { it.endpointId != endpointId }
            handleConnectionFailure(endpointId)
        }
    }

    /**
     * Callback for discovering nearby endpoints.
     */
    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            Log.d(TAG, "Discovered nearby endpoint: ${info.endpointName} ($endpointId) [ServiceId: ${info.serviceId}]")
            _discoveredEndpoints.value = _discoveredEndpoints.value + (endpointId to info.endpointName)

            // Automatically attempt connection upon discovery for background cluster joining
            requestConnection(endpointId, info.endpointName)
        }

        override fun onEndpointLost(endpointId: String) {
            Log.d(TAG, "Lost endpoint: $endpointId")
            _discoveredEndpoints.value = _discoveredEndpoints.value - endpointId
            verifiedEndpoints.remove(endpointId)
            pendingHandshakes.remove(endpointId)?.cancel()
            _connectedPeers.value = _connectedPeers.value.filter { it.endpointId != endpointId }
        }
    }

    /**
     * Callback handling incoming payloads (Bytes, Files, Streams).
     * Enforces app-level protocol handshake checks before emitting payloads.
     */
    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val bytes = payload.asBytes() ?: return

                    // Check for Handshake Messages
                    if (isHandshakeVerify(bytes)) {
                        Log.i(TAG, "Received HANDSHAKE_VERIFY from $endpointId. Replying with HANDSHAKE_ACK...")
                        val ackPayload = Payload.fromBytes(HANDSHAKE_ACK_BYTES)
                        connectionsClient.sendPayload(endpointId, ackPayload)
                        markEndpointVerified(endpointId)
                        return
                    }

                    if (isHandshakeAck(bytes)) {
                        Log.i(TAG, "Received HANDSHAKE_ACK from $endpointId. Handshake complete!")
                        markEndpointVerified(endpointId)
                        return
                    }

                    // For standard app messages, drop if endpoint is unverified
                    if (!verifiedEndpoints.contains(endpointId)) {
                        Log.w(TAG, "Dropping byte payload from unverified endpoint: $endpointId")
                        return
                    }

                    Log.d(TAG, "Received BYTES payload (${bytes.size} bytes) from verified peer $endpointId")
                    scope.launch {
                        _incomingPayloads.emit(
                            IncomingPayload.BytesPayload(
                                endpointId = endpointId,
                                bytes = bytes
                            )
                        )
                    }
                }
                Payload.Type.FILE -> {
                    if (!verifiedEndpoints.contains(endpointId)) {
                        Log.w(TAG, "Dropping FILE payload from unverified endpoint: $endpointId")
                        return
                    }
                    val payloadFile = payload.asFile()?.asJavaFile()
                    Log.d(TAG, "Receiving FILE payload ID ${payload.id} from $endpointId")
                    if (payloadFile != null) {
                        incomingFilePayloads[payload.id] = Pair(endpointId, payloadFile)
                    }
                }
                Payload.Type.STREAM -> {
                    if (!verifiedEndpoints.contains(endpointId)) {
                        Log.w(TAG, "Dropping STREAM payload from unverified endpoint: $endpointId")
                        return
                    }
                    val stream = payload.asStream()?.asInputStream()
                    Log.d(TAG, "STREAM payload ID ${payload.id} received from $endpointId")
                    if (stream != null) {
                        scope.launch {
                            _incomingPayloads.emit(
                                IncomingPayload.StreamPayload(
                                    endpointId = endpointId,
                                    payloadId = payload.id,
                                    stream = stream
                                )
                            )
                        }
                    }
                }
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            val total = update.totalBytes
            val transferred = update.bytesTransferred
            val percentage = if (total > 0) ((transferred * 100) / total).toInt().coerceIn(0, 100) else 0

            val progress = TransferProgress(
                payloadId = update.payloadId,
                bytesTransferred = transferred,
                totalBytes = total,
                progressPercentage = percentage
            )

            scope.launch {
                _payloadProgress.emit(progress)
            }

            if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                val pendingFilePair = incomingFilePayloads.remove(update.payloadId)
                if (pendingFilePair != null) {
                    val (senderEndpointId, file) = pendingFilePair
                    Log.d(TAG, "FILE payload transfer SUCCESS for payload ID ${update.payloadId} from $senderEndpointId. File size: ${file.length()} bytes")
                    scope.launch {
                        _incomingPayloads.emit(
                            IncomingPayload.FilePayload(
                                endpointId = senderEndpointId,
                                payloadId = update.payloadId,
                                file = file,
                                fileName = file.name
                            )
                        )
                    }
                }
            } else if (update.status == PayloadTransferUpdate.Status.FAILURE || update.status == PayloadTransferUpdate.Status.CANCELED) {
                incomingFilePayloads.remove(update.payloadId)
                Log.e(TAG, "FILE payload transfer failed/canceled for payload ID ${update.payloadId}")
            }
        }
    }

    private fun isHandshakeVerify(bytes: ByteArray): Boolean {
        if (bytes.size < 1 + HANDSHAKE_APP_ID.length) return false
        if (bytes[0] != 0x01.toByte()) return false
        val idStr = String(bytes, 1, HANDSHAKE_APP_ID.length, Charsets.UTF_8)
        return idStr == HANDSHAKE_APP_ID
    }

    private fun isHandshakeAck(bytes: ByteArray): Boolean {
        if (bytes.size < 1 + HANDSHAKE_ACK_ID.length) return false
        if (bytes[0] != 0x02.toByte()) return false
        val idStr = String(bytes, 1, HANDSHAKE_ACK_ID.length, Charsets.UTF_8)
        return idStr == HANDSHAKE_ACK_ID
    }

    private fun markEndpointVerified(endpointId: String) {
        verifiedEndpoints.add(endpointId)
        pendingHandshakes.remove(endpointId)?.cancel()

        val endpointName = _discoveredEndpoints.value[endpointId] ?: "Mesh Peer"
        val peer = Peer(
            endpointId = endpointId,
            endpointName = endpointName,
            isConnected = true
        )

        if (_connectedPeers.value.none { it.endpointId == endpointId }) {
            _connectedPeers.value = _connectedPeers.value + peer
            Log.i(TAG, "MeshChat Peer VERIFIED and added to Radar/Active Peers: $endpointName ($endpointId)")
        }
    }

    /**
     * Send raw JSON or text message bytes to verified target endpoint or all verified connected peers.
     */
    fun sendBytes(bytes: ByteArray, targetEndpointId: String? = null): Long? {
        val payload = Payload.fromBytes(bytes)
        val targets = if (targetEndpointId != null) {
            if (verifiedEndpoints.contains(targetEndpointId)) listOf(targetEndpointId) else emptyList()
        } else {
            _connectedPeers.value.map { it.endpointId }
        }

        if (targets.isEmpty()) {
            Log.w(TAG, "No verified connected peers available to send bytes payload")
            return null
        }

        connectionsClient.sendPayload(targets, payload)
            .addOnSuccessListener {
                Log.d(TAG, "Successfully sent BYTES payload ID ${payload.id} to verified targets: $targets")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to send BYTES payload: ${e.message}", e)
            }

        return payload.id
    }

    /**
     * Send a File (Canvas Sketch image or heavy document) to verified target endpoint or connected peers.
     */
    fun sendFile(file: File, targetEndpointId: String? = null): Long? {
        val payload = try {
            Payload.fromFile(file)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating Payload from file: ${e.message}", e)
            return null
        }

        val targets = if (targetEndpointId != null) {
            if (verifiedEndpoints.contains(targetEndpointId)) listOf(targetEndpointId) else emptyList()
        } else {
            _connectedPeers.value.map { it.endpointId }
        }

        if (targets.isEmpty()) {
            Log.w(TAG, "No verified connected peers available to send file payload")
            return null
        }

        connectionsClient.sendPayload(targets, payload)
            .addOnSuccessListener {
                Log.d(TAG, "Successfully initiated FILE payload ID ${payload.id} send to verified targets: $targets")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to send FILE payload: ${e.message}", e)
            }

        return payload.id
    }

    /**
     * Send an InputStream as Payload.Type.STREAM to verified target endpoint or connected peers.
     */
    fun sendStream(inputStream: InputStream, targetEndpointId: String? = null): Long? {
        val payload = Payload.fromStream(inputStream)
        val targets = if (targetEndpointId != null) {
            if (verifiedEndpoints.contains(targetEndpointId)) listOf(targetEndpointId) else emptyList()
        } else {
            _connectedPeers.value.map { it.endpointId }
        }

        if (targets.isEmpty()) {
            Log.w(TAG, "No verified connected peers available to send stream payload")
            return null
        }

        connectionsClient.sendPayload(targets, payload)
            .addOnSuccessListener {
                Log.d(TAG, "Successfully initiated STREAM payload ID ${payload.id} send to verified targets: $targets")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to send STREAM payload: ${e.message}", e)
            }

        return payload.id
    }

    private fun handleConnectionFailure(endpointId: String) {
        val attempts = retryCounts.getOrDefault(endpointId, 0)
        val endpointName = _discoveredEndpoints.value[endpointId] ?: "Unknown Peer"

        if (attempts < MAX_RETRY_ATTEMPTS) {
            retryCounts[endpointId] = attempts + 1
            Log.w(TAG, "Retrying connection to $endpointName ($endpointId), attempt ${attempts + 1}/$MAX_RETRY_ATTEMPTS")
            scope.launch {
                delay(2000L * (attempts + 1))
                if (_discoveredEndpoints.value.containsKey(endpointId)) {
                    requestConnection(endpointId, endpointName)
                }
            }
        } else {
            Log.e(TAG, "Max retry attempts reached for endpoint $endpointId. Abandoning connection.")
            retryCounts.remove(endpointId)
        }
    }

    /**
     * Disconnect from all endpoints and reset state.
     */
    fun disconnectAll() {
        connectionsClient.stopAllEndpoints()
        verifiedEndpoints.clear()
        pendingHandshakes.values.forEach { it.cancel() }
        pendingHandshakes.clear()
        _connectedPeers.value = emptyList()
        _discoveredEndpoints.value = emptyMap()
        _isAdvertising.value = false
        _isDiscovering.value = false
        Log.d(TAG, "Disconnected from all endpoints and cleared handshake states.")
    }
}
