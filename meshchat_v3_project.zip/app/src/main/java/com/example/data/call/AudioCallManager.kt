package com.example.data.call

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.InputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream

/**
 * Production-ready AudioCallManager providing low-latency, full-duplex P2P audio streaming.
 * Uses AudioRecord (16kHz Mono PCM 16-bit) piped into an InputStream for Nearby Connections sending,
 * and AudioTrack for continuous low-latency playback of incoming audio streams.
 */
class AudioCallManager(private val context: Context) {

    companion object {
        private const val TAG = "AudioCallManager"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_IN_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val CHANNEL_OUT_CONFIG = AudioFormat.CHANNEL_OUT_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var echoCanceler: AcousticEchoCanceler? = null

    private var recordJob: Job? = null
    private var playbackJob: Job? = null

    private var pipedOutputStream: PipedOutputStream? = null
    private var pipedInputStream: PipedInputStream? = null

    @Volatile
    var isRecording = false
        private set

    @Volatile
    var isPlaying = false
        private set

    /**
     * Starts audio recording and returns a PipedInputStream ready to be sent over Nearby Connections.
     */
    @SuppressLint("MissingPermission")
    fun startRecording(): InputStream? {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Log.e(TAG, "Cannot start recording: RECORD_AUDIO permission missing")
            return null
        }

        stopRecording()

        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN_CONFIG, AUDIO_FORMAT)
        val bufferSize = (minBufferSize * 2).coerceAtLeast(2048)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                CHANNEL_IN_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            )

            val audioSessionId = audioRecord?.audioSessionId ?: 0
            if (AcousticEchoCanceler.isAvailable() && audioSessionId != 0) {
                echoCanceler = AcousticEchoCanceler.create(audioSessionId)?.apply {
                    enabled = true
                    Log.d(TAG, "AcousticEchoCanceler enabled for session $audioSessionId")
                }
            }

            pipedOutputStream = PipedOutputStream()
            pipedInputStream = PipedInputStream(pipedOutputStream, bufferSize * 4)

            audioRecord?.startRecording()
            isRecording = true

            recordJob = scope.launch(Dispatchers.IO) {
                val buffer = ByteArray(bufferSize)
                try {
                    while (isActive && isRecording) {
                        val readBytes = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                        if (readBytes > 0) {
                            pipedOutputStream?.write(buffer, 0, readBytes)
                            pipedOutputStream?.flush()
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Audio recording loop exception: ${e.message}", e)
                } finally {
                    try {
                        pipedOutputStream?.close()
                    } catch (_: Exception) {}
                }
            }

            Log.i(TAG, "Audio recording started successfully at $SAMPLE_RATE Hz Mono")
            return pipedInputStream
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize AudioRecord: ${e.message}", e)
            stopRecording()
            return null
        }
    }

    /**
     * Starts audio playback by reading directly from the incoming InputStream.
     */
    fun startPlayback(inputStream: InputStream) {
        stopPlayback()

        val minBufferSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_OUT_CONFIG, AUDIO_FORMAT)
        val bufferSize = (minBufferSize * 2).coerceAtLeast(2048)

        try {
            audioTrack = AudioTrack(
                AudioManager.STREAM_VOICE_CALL,
                SAMPLE_RATE,
                CHANNEL_OUT_CONFIG,
                AUDIO_FORMAT,
                bufferSize,
                AudioTrack.MODE_STREAM
            )

            audioTrack?.play()
            isPlaying = true

            playbackJob = scope.launch(Dispatchers.IO) {
                val buffer = ByteArray(bufferSize)
                try {
                    while (isActive && isPlaying) {
                        val readBytes = inputStream.read(buffer, 0, buffer.size)
                        if (readBytes > 0) {
                            audioTrack?.write(buffer, 0, readBytes)
                        } else if (readBytes == -1) {
                            Log.d(TAG, "Incoming audio stream reached EOF")
                            break
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Audio playback loop exception: ${e.message}", e)
                } finally {
                    stopPlayback()
                }
            }

            Log.i(TAG, "Audio playback started successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize AudioTrack: ${e.message}", e)
            stopPlayback()
        }
    }

    /**
     * Stop recording and release AudioRecord resources.
     */
    fun stopRecording() {
        isRecording = false
        recordJob?.cancel()
        recordJob = null

        try {
            echoCanceler?.release()
            echoCanceler = null

            audioRecord?.apply {
                if (recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    stop()
                }
                release()
            }
            audioRecord = null

            pipedOutputStream?.close()
            pipedOutputStream = null
            pipedInputStream?.close()
            pipedInputStream = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioRecord: ${e.message}", e)
        }
    }

    /**
     * Stop playback and release AudioTrack resources.
     */
    fun stopPlayback() {
        isPlaying = false
        playbackJob?.cancel()
        playbackJob = null

        try {
            audioTrack?.apply {
                if (playState == AudioTrack.PLAYSTATE_PLAYING) {
                    stop()
                }
                release()
            }
            audioTrack = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioTrack: ${e.message}", e)
        }
    }

    /**
     * Stop all audio engine jobs and release all hardware resources.
     */
    fun release() {
        stopRecording()
        stopPlayback()
        Log.d(TAG, "AudioCallManager fully released")
    }
}
