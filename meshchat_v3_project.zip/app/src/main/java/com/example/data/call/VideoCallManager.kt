package com.example.data.call

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.Executors

/**
 * Architectural foundation for P2P MJPEG-style video frame streaming over Nearby Connections.
 * Captures frames using CameraX ImageAnalysis, compresses YUV frames to JPEG byte streams,
 * and handles incoming JPEG frame streams for video calls.
 */
class VideoCallManager(private val context: Context) {

    companion object {
        private const val TAG = "VideoCallManager"
        private const val JPEG_QUALITY = 50 // Low latency balance
        private const val FRAME_HEADER_DELIMITER = 0xFF.toByte()
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null

    private var pipedOutputStream: PipedOutputStream? = null
    private var pipedInputStream: PipedInputStream? = null

    private val _latestReceivedFrame = MutableStateFlow<ByteArray?>(null)
    val latestReceivedFrame: StateFlow<ByteArray?> = _latestReceivedFrame.asStateFlow()

    private var frameReceiveJob: Job? = null

    @Volatile
    var isStreaming = false
        private set

    /**
     * Binds CameraX ImageAnalysis and starts compressing camera frames into a pipe stream.
     * Returns the InputStream ready for NearbyConnectionManager stream transport.
     */
    fun startVideoStream(lifecycleOwner: LifecycleOwner): InputStream? {
        stopVideoStream()

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        pipedOutputStream = PipedOutputStream()
        pipedInputStream = PipedInputStream(pipedOutputStream, 1024 * 512)

        isStreaming = true

        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()

                imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                    .build()

                imageAnalysis?.setAnalyzer(cameraExecutor) { imageProxy ->
                    if (!isStreaming) {
                        imageProxy.close()
                        return@setAnalyzer
                    }

                    try {
                        val jpegBytes = imageProxyToJpeg(imageProxy)
                        if (jpegBytes != null && jpegBytes.isNotEmpty()) {
                            // Write size header (4 bytes) followed by JPEG payload
                            val size = jpegBytes.size
                            val header = byteArrayOf(
                                (size shr 24 and 0xFF).toByte(),
                                (size shr 16 and 0xFF).toByte(),
                                (size shr 8 and 0xFF).toByte(),
                                (size and 0xFF).toByte()
                            )
                            synchronized(this) {
                                pipedOutputStream?.write(header)
                                pipedOutputStream?.write(jpegBytes)
                                pipedOutputStream?.flush()
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Frame processing exception: ${e.message}")
                    } finally {
                        imageProxy.close()
                    }
                }

                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(lifecycleOwner, cameraSelector, imageAnalysis)
                Log.i(TAG, "CameraX video stream started successfully")

            } catch (e: Exception) {
                Log.e(TAG, "Failed to bind CameraX ImageAnalysis: ${e.message}", e)
                stopVideoStream()
            }
        }, ContextCompat.getMainExecutor(context))

        return pipedInputStream
    }

    /**
     * Converts an ImageProxy (YUV_420_888) into a compressed JPEG byte array.
     */
    private fun imageProxyToJpeg(image: ImageProxy): ByteArray? {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)

        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), JPEG_QUALITY, out)
        return out.toByteArray()
    }

    /**
     * Reads incoming video frame stream and updates latestReceivedFrame StateFlow for rendering.
     */
    fun startReceivingVideoStream(inputStream: InputStream) {
        stopReceivingVideoStream()

        frameReceiveJob = scope.launch(Dispatchers.IO) {
            val header = ByteArray(4)
            try {
                while (isStreaming) {
                    var bytesRead = 0
                    while (bytesRead < 4) {
                        val read = inputStream.read(header, bytesRead, 4 - bytesRead)
                        if (read == -1) return@launch
                        bytesRead += read
                    }

                    val frameSize = ((header[0].toInt() and 0xFF) shl 24) or
                            ((header[1].toInt() and 0xFF) shl 16) or
                            ((header[2].toInt() and 0xFF) shl 8) or
                            (header[3].toInt() and 0xFF)

                    if (frameSize in 1..(2 * 1024 * 1024)) { // Up to 2MB frame safety limit
                        val frameData = ByteArray(frameSize)
                        var frameBytesRead = 0
                        while (frameBytesRead < frameSize) {
                            val read = inputStream.read(frameData, frameBytesRead, frameSize - frameBytesRead)
                            if (read == -1) return@launch
                            frameBytesRead += read
                        }
                        _latestReceivedFrame.value = frameData
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Video frame receive loop error: ${e.message}")
            }
        }
    }

    /**
     * Stop capturing video stream and unbind CameraX.
     */
    fun stopVideoStream() {
        isStreaming = false
        try {
            cameraProvider?.unbindAll()
            imageAnalysis?.clearAnalyzer()
            pipedOutputStream?.close()
            pipedOutputStream = null
            pipedInputStream?.close()
            pipedInputStream = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping video stream: ${e.message}")
        }
    }

    /**
     * Stop reading incoming video frame stream.
     */
    fun stopReceivingVideoStream() {
        frameReceiveJob?.cancel()
        frameReceiveJob = null
        _latestReceivedFrame.value = null
    }

    /**
     * Release all camera and background thread resources.
     */
    fun release() {
        stopVideoStream()
        stopReceivingVideoStream()
        cameraExecutor.shutdown()
        Log.d(TAG, "VideoCallManager fully released")
    }
}
