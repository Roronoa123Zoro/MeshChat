package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room Entity representing a persisted message (Text, Canvas Sketch, File, Location Ping, or SOS Alert).
 */
@Entity(tableName = "nearby_messages")
data class MessageEntity(
    @PrimaryKey
    val id: String,
    val senderId: String,
    val receiverId: String,
    val messageType: String, // "TEXT", "CANVAS_SKETCH", "FILE", "LOCATION_PING", "SOS"
    val textContent: String? = null,
    val filePath: String? = null,
    val fileName: String? = null,
    val fileSize: Long = 0L,
    val transferProgress: Int = 100, // 0 to 100 percentage for live transfer UI progress circles
    val status: String = "DELIVERED", // "PENDING", "TRANSFERRING", "DELIVERED", "FAILED"
    val timestamp: Long = System.currentTimeMillis(),
    val payloadId: Long = 0L
)
