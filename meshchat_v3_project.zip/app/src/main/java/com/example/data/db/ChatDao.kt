package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {

    // --- Messages ---
    @Query("SELECT * FROM messages WHERE threadId = :threadId ORDER BY timestamp ASC")
    fun getMessagesForThread(threadId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE threadId = :threadId ORDER BY timestamp ASC")
    suspend fun getMessagesOnceForThread(threadId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query("UPDATE messages SET status = :status WHERE messageId = :messageId")
    suspend fun updateMessageStatus(messageId: String, status: MessageStatus)

    @Query("DELETE FROM messages WHERE threadId = :threadId")
    suspend fun deleteMessagesForThread(threadId: String)

    @Query("DELETE FROM messages WHERE threadId IN (:threadIds)")
    suspend fun deleteMessagesForThreads(threadIds: List<String>)

    // --- Chat Threads ---
    @Query("SELECT * FROM chat_threads ORDER BY isPinned DESC, lastMessageTimestamp DESC")
    fun getAllThreads(): Flow<List<ChatThreadEntity>>

    @Query("SELECT * FROM chat_threads WHERE threadId = :threadId LIMIT 1")
    suspend fun getThreadById(threadId: String): ChatThreadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertThread(thread: ChatThreadEntity)

    @Query("UPDATE chat_threads SET isPinned = :isPinned WHERE threadId IN (:threadIds)")
    suspend fun updateThreadsPinStatus(threadIds: List<String>, isPinned: Boolean)

    @Query("UPDATE chat_threads SET lastMessageText = :text, lastMessageTimestamp = :timestamp, unreadCount = :unreadCount WHERE threadId = :threadId")
    suspend fun updateThreadLastMessage(threadId: String, text: String, timestamp: Long, unreadCount: Int = 0)

    @Query("UPDATE chat_threads SET unreadCount = 0 WHERE threadId = :threadId")
    suspend fun markThreadRead(threadId: String)

    @Query("DELETE FROM chat_threads WHERE threadId = :threadId")
    suspend fun deleteThread(threadId: String)

    @Query("DELETE FROM chat_threads WHERE threadId IN (:threadIds)")
    suspend fun deleteThreads(threadIds: List<String>)

    // --- Peers ---
    @Query("SELECT * FROM peers ORDER BY isConnected DESC, signalDbm DESC")
    fun getAllPeers(): Flow<List<PeerEntity>>

    @Query("SELECT * FROM peers WHERE peerId = :peerId LIMIT 1")
    suspend fun getPeerById(peerId: String): PeerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPeer(peer: PeerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPeers(peers: List<PeerEntity>)

    @Query("DELETE FROM peers WHERE peerId IN (:peerIds)")
    suspend fun deletePeers(peerIds: List<String>)

    @Query("UPDATE peers SET isConnected = :isConnected WHERE peerId = :peerId")
    suspend fun updatePeerConnectionStatus(peerId: String, isConnected: Boolean)

    // --- User Profile ---
    @Query("SELECT * FROM user_profile WHERE userId = 'local_user_1' LIMIT 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfileEntity)
}
