package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "peers")
data class PeerEntity(
    @PrimaryKey
    val peerId: String, // Bluetooth MAC address or Mesh Node ID
    val name: String,
    val statusMessage: String = "Online via Mesh",
    val avatarColorHex: String = "#3B82F6",
    val signalDbm: Int = -65, // Signal strength RSSI
    val distanceMeters: Float = 3.5f,
    val isConnected: Boolean = false,
    val isBonded: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val isMeshRelayNode: Boolean = true,
    val batteryLevel: Int = 85
)
