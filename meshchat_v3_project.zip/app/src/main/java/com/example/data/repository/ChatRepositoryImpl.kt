package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.MessageDao
import com.example.data.local.MessageEntity
import com.example.data.nearby.IncomingPayload
import com.example.data.nearby.NearbyConnectionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Production-ready ChatRepository implementation processing raw IncomingPayload streams (Bytes and Files)
 * from NearbyConnectionManager into persisted Room MessageEntity database records.
 * Tracks live transfer progress for files and canvas sketches, and exposes reactivity to UI.
 */
class ChatRepositoryImpl(
    private val nearbyConnectionManager: NearbyConnectionManager,
    private val messageDao: MessageDao,
    private val context: Context,
    private val notificationHelper: com.example.system.ChatNotificationHelper = com.example.system.ChatNotificationHelper(context)
) : ChatRepository {

    companion object {
        private const val TAG = "ChatRepositoryImpl"
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    init {
        observeIncomingPayloads()
        observePayloadProgress()
    }

    /**
     * Continuously collect incoming payloads (Bytes and Files) from NearbyConnectionManager.
     */
    private fun observeIncomingPayloads() {
        scope.launch {
            nearbyConnectionManager.incomingPayloads.collect { incoming ->
                when (incoming) {
                    is IncomingPayload.BytesPayload -> {
                        handleIncomingBytes(incoming)
                    }
                    is IncomingPayload.FilePayload -> {
                        handleIncomingFile(incoming)
                    }
                    is IncomingPayload.StreamPayload -> {
                        // Stream payloads handled by CallRepository for P2P audio/video calls
                    }
                }
            }
        }
    }

    /**
     * Continuously collect real-time transfer progress updates and update corresponding database records.
     */
    private fun observePayloadProgress() {
        scope.launch {
            nearbyConnectionManager.payloadProgress.collect { progress ->
                try {
                    val status = if (progress.progressPercentage >= 100) "DELIVERED" else "TRANSFERRING"
                    messageDao.updateProgressAndStatusByPayloadId(
                        payloadId = progress.payloadId,
                        progress = progress.progressPercentage,
                        status = status
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Error updating payload progress in DB: ${e.message}", e)
                }
            }
        }
    }

    /**
     * Parse incoming BytesPayload (JSON text, SOS broadcast, or Location Ping) and persist to Room DB.
     */
    private suspend fun handleIncomingBytes(incoming: IncomingPayload.BytesPayload) {
        withContext(Dispatchers.IO) {
            try {
                val jsonString = String(incoming.bytes, Charsets.UTF_8)
                val json = JSONObject(jsonString)
                val msgType = json.optString("type", "TEXT")
                val content = json.optString("content", jsonString)
                // Always trust the live connection's endpoint ID for the sender, not the
                // self-reported "senderId" field in the payload (the other device writes
                // the literal placeholder "me" there, from its own point of view).
                val sender = incoming.endpointId
                val receiver = "me"
                val msgId = json.optString("id", UUID.randomUUID().toString())

                val entity = MessageEntity(
                    id = msgId,
                    senderId = sender,
                    receiverId = receiver,
                    messageType = msgType,
                    textContent = content,
                    filePath = null,
                    fileName = null,
                    fileSize = incoming.bytes.size.toLong(),
                    transferProgress = 100,
                    status = "DELIVERED",
                    timestamp = incoming.timestamp
                )
                messageDao.insertMessage(entity)
                val senderAlias = nearbyConnectionManager.discoveredEndpoints.value[sender] ?: sender
                notificationHelper.showIncomingMessageNotification(
                    senderId = sender,
                    senderName = senderAlias,
                    messageText = content,
                    messageType = msgType
                )
            } catch (e: Exception) {
                // Fallback for raw non-JSON text payloads
                val fallbackText = String(incoming.bytes, Charsets.UTF_8)
                val entity = MessageEntity(
                    id = UUID.randomUUID().toString(),
                    senderId = incoming.endpointId,
                    receiverId = "me",
                    messageType = "TEXT",
                    textContent = fallbackText,
                    filePath = null,
                    fileName = null,
                    fileSize = incoming.bytes.size.toLong(),
                    transferProgress = 100,
                    status = "DELIVERED",
                    timestamp = incoming.timestamp
                )
                messageDao.insertMessage(entity)
                val senderAlias = nearbyConnectionManager.discoveredEndpoints.value[incoming.endpointId] ?: incoming.endpointId
                notificationHelper.showIncomingMessageNotification(
                    senderId = incoming.endpointId,
                    senderName = senderAlias,
                    messageText = fallbackText,
                    messageType = "TEXT"
                )
            }
        }
    }

    /**
     * Move temporary received file to app permanent internal storage, construct MessageEntity, and persist to Room DB.
     */
    private suspend fun handleIncomingFile(incoming: IncomingPayload.FilePayload) {
        withContext(Dispatchers.IO) {
            try {
                val receivedDir = File(context.filesDir, "received_files").apply { if (!exists()) mkdirs() }
                val targetFileName = incoming.fileName ?: "file_${System.currentTimeMillis()}"
                val destFile = File(receivedDir, "${System.currentTimeMillis()}_$targetFileName")

                incoming.file.inputStream().use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }

                val isImage = destFile.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "gif")
                val type = if (isImage) "CANVAS_SKETCH" else "FILE"

                val existing = messageDao.getMessageByPayloadId(incoming.payloadId)
                if (existing != null) {
                    val updated = existing.copy(
                        filePath = destFile.absolutePath,
                        fileName = destFile.name,
                        fileSize = destFile.length(),
                        transferProgress = 100,
                        status = "DELIVERED"
                    )
                    messageDao.updateMessage(updated)
                } else {
                    val entity = MessageEntity(
                        id = UUID.randomUUID().toString(),
                        senderId = incoming.endpointId,
                        receiverId = "me",
                        messageType = type,
                        textContent = destFile.name,
                        filePath = destFile.absolutePath,
                        fileName = destFile.name,
                        fileSize = destFile.length(),
                        transferProgress = 100,
                        status = "DELIVERED",
                        timestamp = incoming.timestamp,
                        payloadId = incoming.payloadId
                    )
                    messageDao.insertMessage(entity)
                }
                val senderAlias = nearbyConnectionManager.discoveredEndpoints.value[incoming.endpointId] ?: incoming.endpointId
                notificationHelper.showIncomingMessageNotification(
                    senderId = incoming.endpointId,
                    senderName = senderAlias,
                    messageText = destFile.name,
                    messageType = type
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error handling incoming file payload: ${e.message}", e)
            }
        }
    }

    override suspend fun sendTextMessage(receiverId: String, text: String, messageType: String) {
        withContext(Dispatchers.IO) {
            val msgId = UUID.randomUUID().toString()
            val json = JSONObject().apply {
                put("id", msgId)
                put("senderId", "me")
                put("receiverId", receiverId)
                put("type", messageType)
                put("content", text)
            }
            val bytes = json.toString().toByteArray(Charsets.UTF_8)
            val sentPayloadId = nearbyConnectionManager.sendBytes(bytes, targetEndpointId = receiverId)

            val entity = MessageEntity(
                id = msgId,
                senderId = "me",
                receiverId = receiverId,
                messageType = messageType,
                textContent = text,
                filePath = null,
                fileName = null,
                fileSize = bytes.size.toLong(),
                transferProgress = if (sentPayloadId != null) 100 else 0,
                status = if (sentPayloadId != null) "DELIVERED" else "FAILED",
                timestamp = System.currentTimeMillis(),
                payloadId = sentPayloadId ?: 0L
            )
            messageDao.insertMessage(entity)
        }
    }

    override suspend fun sendCanvasSketch(receiverId: String, imageFile: File) {
        withContext(Dispatchers.IO) {
            val payloadId = nearbyConnectionManager.sendFile(imageFile, targetEndpointId = receiverId) ?: 0L
            val msgId = UUID.randomUUID().toString()

            val entity = MessageEntity(
                id = msgId,
                senderId = "me",
                receiverId = receiverId,
                messageType = "CANVAS_SKETCH",
                textContent = imageFile.name,
                filePath = imageFile.absolutePath,
                fileName = imageFile.name,
                fileSize = imageFile.length(),
                transferProgress = 0,
                status = "TRANSFERRING",
                timestamp = System.currentTimeMillis(),
                payloadId = payloadId
            )
            messageDao.insertMessage(entity)
        }
    }

    override suspend fun sendFile(receiverId: String, file: File) {
        withContext(Dispatchers.IO) {
            val payloadId = nearbyConnectionManager.sendFile(file, targetEndpointId = receiverId) ?: 0L
            val msgId = UUID.randomUUID().toString()

            val entity = MessageEntity(
                id = msgId,
                senderId = "me",
                receiverId = receiverId,
                messageType = "FILE",
                textContent = file.name,
                filePath = file.absolutePath,
                fileName = file.name,
                fileSize = file.length(),
                transferProgress = 0,
                status = "TRANSFERRING",
                timestamp = System.currentTimeMillis(),
                payloadId = payloadId
            )
            messageDao.insertMessage(entity)
        }
    }

    override fun getMessagesForPeer(peerId: String): Flow<List<MessageEntity>> {
        return messageDao.getMessagesForPeer(peerId)
    }
}
