package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for local message persistence and status/progress updates.
 */
@Dao
interface MessageDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Update
    suspend fun updateMessage(message: MessageEntity)

    @Query("SELECT * FROM nearby_messages WHERE senderId = :peerId OR receiverId = :peerId ORDER BY timestamp ASC")
    fun getMessagesForPeer(peerId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM nearby_messages WHERE id = :id LIMIT 1")
    suspend fun getMessageById(id: String): MessageEntity?

    @Query("SELECT * FROM nearby_messages WHERE payloadId = :payloadId LIMIT 1")
    suspend fun getMessageByPayloadId(payloadId: Long): MessageEntity?

    @Query("UPDATE nearby_messages SET transferProgress = :progress, status = :status WHERE id = :id")
    suspend fun updateProgressAndStatusById(id: String, progress: Int, status: String)

    @Query("UPDATE nearby_messages SET transferProgress = :progress, status = :status WHERE payloadId = :payloadId")
    suspend fun updateProgressAndStatusByPayloadId(payloadId: Long, progress: Int, status: String)

    @Query("DELETE FROM nearby_messages WHERE senderId = :peerId OR receiverId = :peerId")
    suspend fun deleteMessagesForPeer(peerId: String)
}
