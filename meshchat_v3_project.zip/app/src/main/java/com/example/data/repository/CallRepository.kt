package com.example.data.repository

import android.content.Context
import android.util.Log
import androidx.lifecycle.LifecycleOwner
import com.example.data.call.AudioCallManager
import com.example.data.call.CallAction
import com.example.data.call.CallMessage
import com.example.data.call.CallType
import com.example.data.call.VideoCallManager
import com.example.data.nearby.IncomingPayload
import com.example.data.nearby.NearbyConnectionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

/**
 * State of an offline P2P call session.
 */
sealed class CallState {
    object Idle : CallState()
    data class RingingOutgoing(val callId: String, val peerId: String, val type: CallType) : CallState()
    data class RingingIncoming(val callId: String, val peerId: String, val type: CallType) : CallState()
    data class InCall(val callId: String, val peerId: String, val type: CallType) : CallState()
}

/**
 * Unified CallRepository managing P2P offline call signaling (OFFER, ANSWER, REJECT, END)
 * and directing audio/video stream payloads through AudioCallManager and VideoCallManager.
 */
class CallRepository(
    private val nearbyConnectionManager: NearbyConnectionManager,
    private val audioCallManager: AudioCallManager,
    private val videoCallManager: VideoCallManager,
    private val context: Context
) {
    companion object {
        private const val TAG = "CallRepository"
        private const val SIGNAL_TYPE = "CALL_SIGNAL"
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _callState = MutableStateFlow<CallState>(CallState.Idle)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    init {
        observeIncomingPayloads()
    }

    /**
     * Listen for incoming P2P call signals and stream payloads.
     */
    private fun observeIncomingPayloads() {
        scope.launch {
            nearbyConnectionManager.incomingPayloads.collect { incoming ->
                when (incoming) {
                    is IncomingPayload.BytesPayload -> {
                        handleSignalingPayload(incoming)
                    }
                    is IncomingPayload.StreamPayload -> {
                        handleStreamPayload(incoming)
                    }
                    else -> {}
                }
            }
        }
    }

    /**
     * Process incoming JSON signaling payload.
     */
    private fun handleSignalingPayload(incoming: IncomingPayload.BytesPayload) {
        try {
            val jsonString = String(incoming.bytes, Charsets.UTF_8)
            val json = JSONObject(jsonString)
            if (json.optString("type") != SIGNAL_TYPE) return

            val callId = json.getString("callId")
            val senderId = json.getString("senderId")
            val actionStr = json.getString("action")
            val callTypeStr = json.getString("callType")

            val action = CallAction.valueOf(actionStr)
            val type = CallType.valueOf(callTypeStr)

            when (action) {
                CallAction.OFFER -> {
                    if (_callState.value is CallState.Idle) {
                        _callState.value = CallState.RingingIncoming(callId, senderId, type)
                        Log.i(TAG, "Incoming call offer from $senderId for call $callId")
                    } else {
                        // Busy, auto-reject
                        sendSignaling(senderId, callId, CallAction.REJECT, type)
                    }
                }
                CallAction.ANSWER -> {
                    val current = _callState.value
                    if (current is CallState.RingingOutgoing && current.callId == callId) {
                        _callState.value = CallState.InCall(callId, senderId, type)
                        Log.i(TAG, "Call $callId answered by $senderId. Establishing streams...")
                        startLocalAudioStream(senderId)
                    }
                }
                CallAction.REJECT -> {
                    Log.i(TAG, "Call $callId rejected by $senderId")
                    cleanupCall()
                }
                CallAction.END -> {
                    Log.i(TAG, "Call $callId ended by $senderId")
                    cleanupCall()
                }
            }
        } catch (e: Exception) {
            // Not a call signaling message
        }
    }

    /**
     * Handle incoming stream payload from peer for audio or video playback.
     */
    private fun handleStreamPayload(incoming: IncomingPayload.StreamPayload) {
        val currentState = _callState.value
        if (currentState is CallState.InCall && currentState.peerId == incoming.endpointId) {
            Log.i(TAG, "Receiving active call stream payload ${incoming.payloadId} from ${incoming.endpointId}, type: ${currentState.type}")
            if (currentState.type == CallType.VIDEO) {
                if (!audioCallManager.isPlaying) {
                    audioCallManager.startPlayback(incoming.stream)
                } else {
                    videoCallManager.startReceivingVideoStream(incoming.stream)
                }
            } else {
                audioCallManager.startPlayback(incoming.stream)
            }
        }
    }

    /**
     * Initiate an outgoing call (Audio or Video).
     */
    fun initiateCall(receiverId: String, type: CallType) {
        if (_callState.value !is CallState.Idle) return

        val callId = UUID.randomUUID().toString()
        _callState.value = CallState.RingingOutgoing(callId, receiverId, type)
        sendSignaling(receiverId, callId, CallAction.OFFER, type)
        Log.i(TAG, "Initiated outgoing call $callId to $receiverId")
    }

    /**
     * Accept an incoming call.
     */
    fun acceptCall(lifecycleOwner: LifecycleOwner? = null) {
        val currentState = _callState.value
        if (currentState is CallState.RingingIncoming) {
            val (callId, peerId, type) = currentState
            _callState.value = CallState.InCall(callId, peerId, type)
            sendSignaling(peerId, callId, CallAction.ANSWER, type)
            Log.i(TAG, "Accepted call $callId from $peerId")
            startLocalAudioStream(peerId)
            if (type == CallType.VIDEO && lifecycleOwner != null) {
                startLocalVideoStream(peerId, lifecycleOwner)
            }
        }
    }

    /**
     * Start local CameraX video stream and transmit it over NearbyConnectionManager.
     */
    fun startLocalVideoStream(targetEndpointId: String, lifecycleOwner: LifecycleOwner) {
        val videoStream = videoCallManager.startVideoStream(lifecycleOwner)
        if (videoStream != null) {
            nearbyConnectionManager.sendStream(videoStream, targetEndpointId)
            Log.i(TAG, "Video stream recording and send initiated to $targetEndpointId")
        } else {
            Log.e(TAG, "Failed to start local video stream")
        }
    }

    /**
     * Reject an incoming call.
     */
    fun rejectCall() {
        val currentState = _callState.value
        if (currentState is CallState.RingingIncoming) {
            sendSignaling(currentState.peerId, currentState.callId, CallAction.REJECT, currentState.type)
        }
        cleanupCall()
    }

    /**
     * End an active or ringing call.
     */
    fun endCall() {
        val currentState = _callState.value
        when (currentState) {
            is CallState.InCall -> sendSignaling(currentState.peerId, currentState.callId, CallAction.END, currentState.type)
            is CallState.RingingOutgoing -> sendSignaling(currentState.peerId, currentState.callId, CallAction.END, currentState.type)
            is CallState.RingingIncoming -> sendSignaling(currentState.peerId, currentState.callId, CallAction.REJECT, currentState.type)
            else -> {}
        }
        cleanupCall()
    }

    /**
     * Start local AudioRecord stream and transmit it over NearbyConnectionManager.
     */
    private fun startLocalAudioStream(targetEndpointId: String) {
        val audioStream = audioCallManager.startRecording()
        if (audioStream != null) {
            nearbyConnectionManager.sendStream(audioStream, targetEndpointId)
            Log.i(TAG, "Audio stream recording and send initiated to $targetEndpointId")
        } else {
            Log.e(TAG, "Failed to start local audio recording stream")
        }
    }

    /**
     * Send signaling JSON payload over NearbyConnectionManager.
     */
    private fun sendSignaling(targetEndpointId: String, callId: String, action: CallAction, type: CallType) {
        val json = JSONObject().apply {
            put("type", SIGNAL_TYPE)
            put("callId", callId)
            put("senderId", "me")
            put("receiverId", targetEndpointId)
            put("action", action.name)
            put("callType", type.name)
            put("timestamp", System.currentTimeMillis())
        }
        nearbyConnectionManager.sendBytes(json.toString().toByteArray(Charsets.UTF_8), targetEndpointId)
    }

    /**
     * Clean up call state and release audio/video engine streams.
     */
    private fun cleanupCall() {
        audioCallManager.stopRecording()
        audioCallManager.stopPlayback()
        videoCallManager.stopVideoStream()
        videoCallManager.stopReceivingVideoStream()
        _callState.value = CallState.Idle
        Log.i(TAG, "Call session cleaned up and reset to Idle")
    }
}
