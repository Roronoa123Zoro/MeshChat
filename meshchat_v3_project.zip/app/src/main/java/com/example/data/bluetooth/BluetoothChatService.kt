package com.example.data.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.util.UUID

/**
 * BluetoothChatService manages Bluetooth discovery, RFCOMM server socket connection,
 * client socket connection, and bidirectional message streaming.
 */
class BluetoothChatService(private val context: Context) {

    companion object {
        private const val TAG = "BluetoothChatService"
        private const val SERVICE_NAME = "BluetoothChatService"
        val CHAT_UUID: UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66")
    }

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // --- State & Shared Flows ---
    private val _isBluetoothSupported = MutableStateFlow(bluetoothAdapter != null)
    val isBluetoothSupported: StateFlow<Boolean> = _isBluetoothSupported.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(bluetoothAdapter?.isEnabled == true)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<BluetoothDevice>> = _discoveredDevices.asStateFlow()

    private val _connectedDevice = MutableStateFlow<BluetoothDevice?>(null)
    val connectedDevice: StateFlow<BluetoothDevice?> = _connectedDevice.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val incomingMessages: SharedFlow<String> = _incomingMessages.asSharedFlow()

    // Sockets & Jobs
    private var serverSocket: BluetoothServerSocket? = null
    private var activeSocket: BluetoothSocket? = null
    private var serverJob: Job? = null
    private var clientJob: Job? = null
    private var readerJob: Job? = null

    init {
        registerReceiver()
        if (bluetoothAdapter?.isEnabled == true) {
            startServerSocket()
        }
    }

    // --- Discovery Methods ---
    @SuppressLint("MissingPermission")
    fun startDiscovery(): Boolean {
        val adapter = bluetoothAdapter ?: return false
        if (!adapter.isEnabled) return false

        try {
            if (adapter.isDiscovering) {
                adapter.cancelDiscovery()
            }
            val started = adapter.startDiscovery()
            _isDiscovering.value = started
            return started
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException during startDiscovery: ${e.message}")
            return false
        }
    }

    @SuppressLint("MissingPermission")
    fun cancelDiscovery() {
        try {
            if (bluetoothAdapter?.isDiscovering == true) {
                bluetoothAdapter.cancelDiscovery()
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException during cancelDiscovery: ${e.message}")
        }
        _isDiscovering.value = false
    }

    // --- Bluetooth Server Socket Listener ---
    @SuppressLint("MissingPermission")
    fun startServerSocket() {
        val adapter = bluetoothAdapter ?: return
        if (!adapter.isEnabled || serverJob?.isActive == true) return

        serverJob = scope.launch {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, CHAT_UUID)
                _isListening.value = true
                Log.d(TAG, "BluetoothServerSocket listening on $CHAT_UUID")

                while (isActive) {
                    val socket = try {
                        serverSocket?.accept()
                    } catch (e: Exception) {
                        null
                    }

                    if (socket != null) {
                        Log.d(TAG, "Accepted connection from ${socket.remoteDevice?.address}")
                        handleConnectedSocket(socket)
                        break // Single client connection mode per server socket instance
                    }
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException in server socket: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Error in server socket: ${e.message}")
            } finally {
                _isListening.value = false
            }
        }
    }

    // --- Client Connection ---
    @SuppressLint("MissingPermission")
    fun connectToDevice(device: BluetoothDevice) {
        val adapter = bluetoothAdapter ?: return
        if (!adapter.isEnabled) return

        clientJob = scope.launch {
            try {
                cancelDiscovery()
                Log.d(TAG, "Connecting to device ${device.address}...")

                val socket = device.createRfcommSocketToServiceRecord(CHAT_UUID)
                socket.connect()

                Log.d(TAG, "Successfully connected to ${device.address}")
                handleConnectedSocket(socket)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to connect to ${device.address}: ${e.message}")
                closeActiveSocket()
            }
        }
    }

    // --- Message Streaming & Data Transfer ---
    private fun handleConnectedSocket(socket: BluetoothSocket) {
        closeActiveSocket()
        activeSocket = socket
        _connectedDevice.value = socket.remoteDevice

        readerJob = scope.launch {
            try {
                val reader = BufferedReader(InputStreamReader(socket.inputStream))
                while (isActive && socket.isConnected) {
                    val line = reader.readLine() ?: break
                    Log.d(TAG, "Received message stream line: $line")
                    _incomingMessages.emit(line)
                }
            } catch (e: Exception) {
                Log.d(TAG, "Socket reader disconnected: ${e.message}")
            } finally {
                closeActiveSocket()
            }
        }
    }

    fun sendMessage(message: String): Boolean {
        val socket = activeSocket ?: return false
        if (!socket.isConnected) return false

        return try {
            val writer = OutputStreamWriter(socket.outputStream)
            writer.write(message + "\n")
            writer.flush()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send message: ${e.message}")
            closeActiveSocket()
            false
        }
    }

    fun closeActiveSocket() {
        readerJob?.cancel()
        readerJob = null
        try {
            activeSocket?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing active socket: ${e.message}")
        }
        activeSocket = null
        _connectedDevice.value = null
    }

    fun stopService() {
        cancelDiscovery()
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing server socket: ${e.message}")
        }
        serverJob?.cancel()
        closeActiveSocket()
        try {
            context.unregisterReceiver(bluetoothReceiver)
        } catch (e: Exception) {
            // Receiver might already be unregistered
        }
    }

    // --- BroadcastReceiver for Discovery & Bluetooth State ---
    private val bluetoothReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    val enabled = state == BluetoothAdapter.STATE_ON
                    _isBluetoothEnabled.value = enabled
                    if (enabled) {
                        startServerSocket()
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    _isDiscovering.value = true
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _isDiscovering.value = false
                }
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    if (device != null) {
                        _discoveredDevices.update { current ->
                            if (current.none { it.address == device.address }) {
                                current + device
                            } else {
                                current
                            }
                        }
                    }
                }
            }
        }
    }

    private fun registerReceiver() {
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_FOUND)
        }
        try {
            context.registerReceiver(bluetoothReceiver, filter)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register broadcast receiver: ${e.message}")
        }
    }
}
