package com.example.data

import android.content.Context
import com.example.data.call.AudioCallManager
import com.example.data.call.VideoCallManager
import com.example.data.local.AppDatabase
import com.example.data.nearby.NearbyConnectionManager
import com.example.data.nearby.QrPairingManager
import com.example.data.repository.CallRepository
import com.example.data.repository.ChatRepository
import com.example.data.repository.ChatRepositoryImpl
import com.example.system.ChatNotificationHelper

/**
 * Thread-safe Service Locator providing singletons for Nearby Connections,
 * Room Database, Repositories, and Media Stream Managers across ViewModels.
 */
object MeshServiceLocator {

    @Volatile
    private var nearbyConnectionManager: NearbyConnectionManager? = null

    @Volatile
    private var chatRepository: ChatRepository? = null

    @Volatile
    private var callRepository: CallRepository? = null

    @Volatile
    private var audioCallManager: AudioCallManager? = null

    @Volatile
    private var videoCallManager: VideoCallManager? = null

    @Volatile
    private var qrPairingManager: QrPairingManager? = null

    @Volatile
    private var notificationHelper: ChatNotificationHelper? = null

    fun getQrPairingManager(context: Context): QrPairingManager {
        return qrPairingManager ?: synchronized(this) {
            qrPairingManager ?: QrPairingManager(getNearbyConnectionManager(context)).also {
                qrPairingManager = it
            }
        }
    }

    fun getChatNotificationHelper(context: Context): ChatNotificationHelper {
        return notificationHelper ?: synchronized(this) {
            notificationHelper ?: ChatNotificationHelper(context.applicationContext).also {
                notificationHelper = it
            }
        }
    }

    fun getNearbyConnectionManager(context: Context): NearbyConnectionManager {
        return nearbyConnectionManager ?: synchronized(this) {
            nearbyConnectionManager ?: NearbyConnectionManager(context.applicationContext).also {
                nearbyConnectionManager = it
            }
        }
    }

    fun getChatRepository(context: Context): ChatRepository {
        return chatRepository ?: synchronized(this) {
            chatRepository ?: run {
                val db = AppDatabase.getInstance(context.applicationContext)
                val manager = getNearbyConnectionManager(context)
                ChatRepositoryImpl(manager, db.messageDao(), context.applicationContext).also {
                    chatRepository = it
                }
            }
        }
    }

    fun getAudioCallManager(context: Context): AudioCallManager {
        return audioCallManager ?: synchronized(this) {
            audioCallManager ?: AudioCallManager(context.applicationContext).also {
                audioCallManager = it
            }
        }
    }

    fun getVideoCallManager(context: Context): VideoCallManager {
        return videoCallManager ?: synchronized(this) {
            videoCallManager ?: VideoCallManager(context.applicationContext).also {
                videoCallManager = it
            }
        }
    }

    fun getCallRepository(context: Context): CallRepository {
        return callRepository ?: synchronized(this) {
            callRepository ?: run {
                val manager = getNearbyConnectionManager(context)
                val audio = getAudioCallManager(context)
                val video = getVideoCallManager(context)
                CallRepository(manager, audio, video, context.applicationContext).also {
                    callRepository = it
                }
            }
        }
    }
}
