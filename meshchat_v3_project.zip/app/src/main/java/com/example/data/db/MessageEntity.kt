package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageStatus {
    PENDING,
    TRANSMITTING,
    DELIVERED,
    READ,
    RELAYED,
    FAILED
}

enum class MessageType {
    TEXT,
    IMAGE_CANVAS,
    LOCATION_PING,
    SOS_BROADCAST,
    VOICE_PING,
    FILE_ATTACHMENT
}

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey
    val messageId: String,
    val threadId: String,
    val senderId: String,
    val senderName: String,
    val recipientId: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.DELIVERED,
    val messageType: MessageType = MessageType.TEXT,
    val extraData: String? = null, // Base64 image data or latitude,longitude string
    val isOutgoing: Boolean = true,
    val relayHops: Int = 0
)
