package com.example.data.call

/**
 * Enum representing call negotiation actions.
 */
enum class CallAction {
    OFFER,
    ANSWER,
    REJECT,
    END
}

/**
 * Enum representing call type (Audio or Video).
 */
enum class CallType {
    AUDIO,
    VIDEO
}

/**
 * Model representing a call signaling message sent over P2P JSON payloads.
 */
data class CallMessage(
    val callId: String,
    val senderId: String,
    val receiverId: String,
    val action: CallAction,
    val type: CallType,
    val timestamp: Long = System.currentTimeMillis()
)
