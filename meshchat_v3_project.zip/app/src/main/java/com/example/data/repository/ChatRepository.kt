package com.example.data.repository

import com.example.data.local.MessageEntity
import kotlinx.coroutines.flow.Flow
import java.io.File

/**
 * Repository interface for managing nearby offline chat operations and data streams.
 */
interface ChatRepository {
    suspend fun sendTextMessage(receiverId: String, text: String, messageType: String = "TEXT")
    suspend fun sendCanvasSketch(receiverId: String, imageFile: File)
    suspend fun sendFile(receiverId: String, file: File)
    fun getMessagesForPeer(peerId: String): Flow<List<MessageEntity>>
}
