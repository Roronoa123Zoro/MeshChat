package com.example.data.bluetooth

import org.json.JSONObject
import java.util.UUID

enum class PacketType {
    HANDSHAKE,
    CHAT_TEXT,
    CHAT_IMAGE,
    LOCATION_SHARE,
    SOS_BROADCAST,
    FILE_TRANSFER,
    DELIVERY_ACK,
    PING
}

data class MeshPacket(
    val packetId: String = UUID.randomUUID().toString(),
    val type: PacketType,
    val senderId: String,
    val senderName: String,
    val targetId: String,
    val threadId: String,
    val payload: String,
    val timestamp: Long = System.currentTimeMillis(),
    val ttl: Int = 3,
    val extraData: String? = null
) {
    fun toJson(): String {
        val json = JSONObject()
        json.put("packetId", packetId)
        json.put("type", type.name)
        json.put("senderId", senderId)
        json.put("senderName", senderName)
        json.put("targetId", targetId)
        json.put("threadId", threadId)
        json.put("payload", payload)
        json.put("timestamp", timestamp)
        json.put("ttl", ttl)
        if (extraData != null) json.put("extraData", extraData)
        return json.toString()
    }

    companion object {
        fun fromJson(jsonStr: String): MeshPacket? {
            return try {
                val json = JSONObject(jsonStr)
                MeshPacket(
                    packetId = json.getString("packetId"),
                    type = PacketType.valueOf(json.getString("type")),
                    senderId = json.getString("senderId"),
                    senderName = json.getString("senderName"),
                    targetId = json.getString("targetId"),
                    threadId = json.getString("threadId"),
                    payload = json.getString("payload"),
                    timestamp = json.getLong("timestamp"),
                    ttl = json.optInt("ttl", 3),
                    extraData = if (json.has("extraData")) json.getString("extraData") else null
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
