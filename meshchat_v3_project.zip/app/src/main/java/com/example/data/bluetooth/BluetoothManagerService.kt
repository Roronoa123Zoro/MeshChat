package com.example.data.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.util.Log
import com.example.data.db.PeerEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID

class BluetoothManagerService(private val context: Context) {

    companion object {
        private const val TAG = "BluetoothManagerService"
        private const val SERVICE_NAME = "MeshChatOfflineService"
        val MESH_CHAT_UUID: UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66")
    }

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    val chatService: BluetoothChatService = BluetoothChatService(context)

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // --- State Flows ---
    private val _isBluetoothSupported = MutableStateFlow(bluetoothAdapter != null)
    val isBluetoothSupported: StateFlow<Boolean> = _isBluetoothSupported.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(bluetoothAdapter?.isEnabled == true)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _useSimulator = MutableStateFlow(false)
    val useSimulator: StateFlow<Boolean> = _useSimulator.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<PeerEntity>>(emptyList())
    val discoveredPeers: StateFlow<List<PeerEntity>> = _discoveredPeers.asStateFlow()

    private val _connectedPeersMap = MutableStateFlow<Map<String, PeerEntity>>(emptyMap())
    val connectedPeers: StateFlow<List<PeerEntity>> = _connectedPeersMap.map { it.values.toList() }
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    private val _incomingPackets = MutableSharedFlow<MeshPacket>(extraBufferCapacity = 64)
    val incomingPackets: SharedFlow<MeshPacket> = _incomingPackets.asSharedFlow()

    private val _packetsSent = MutableStateFlow(0)
    val packetsSent: StateFlow<Int> = _packetsSent.asStateFlow()

    private val _packetsReceived = MutableStateFlow(0)
    val packetsReceived: StateFlow<Int> = _packetsReceived.asStateFlow()

    // Sockets
    private val activeSockets = mutableMapOf<String, BluetoothSocket>()
    private var serverSocket: BluetoothServerSocket? = null
    private var serverJob: Job? = null
    private var simulatorJob: Job? = null

    init {
        registerBluetoothReceiver()
        initSimulatedPeers()
        if (bluetoothAdapter?.isEnabled == true) {
            startRfcommServer()
            loadBondedDevices()
        }
    }

    fun setSimulatorEnabled(enabled: Boolean) {
        _useSimulator.value = enabled
        if (enabled) {
            startSimulatorEngine()
        }
    }

    // --- Real Hardware Discovery ---
    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        if (_useSimulator.value) {
            simulateScan()
            return
        }

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            _useSimulator.value = true
            simulateScan()
            return
        }

        try {
            if (bluetoothAdapter.isDiscovering) {
                bluetoothAdapter.cancelDiscovery()
            }
            val success = bluetoothAdapter.startDiscovery()
            _isDiscovering.value = success
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing Bluetooth permissions for discovery: ${e.message}")
            _useSimulator.value = true
            simulateScan()
        }
    }

    @SuppressLint("MissingPermission")
    fun loadBondedDevices() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) return
        try {
            val bonded = bluetoothAdapter.bondedDevices ?: emptySet()
            val list = bonded.map { device ->
                PeerEntity(
                    peerId = device.address ?: UUID.randomUUID().toString(),
                    name = device.name ?: "Bonded Device",
                    statusMessage = "Paired Bluetooth Device",
                    avatarColorHex = "#3B82F6",
                    signalDbm = -60,
                    distanceMeters = 2.0f,
                    isConnected = activeSockets.containsKey(device.address),
                    isBonded = true,
                    lastSeenTimestamp = System.currentTimeMillis()
                )
            }
            _discoveredPeers.update { current ->
                (current + list).distinctBy { it.peerId }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException loading bonded devices: ${e.message}")
        }
    }

    // --- RFCOMM Server Socket ---
    @SuppressLint("MissingPermission")
    fun startRfcommServer() {
        if (serverJob?.isActive == true || bluetoothAdapter == null) return

        serverJob = scope.launch {
            try {
                serverSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, MESH_CHAT_UUID)
                _isServerRunning.value = true
                Log.d(TAG, "RFCOMM Server listening on $MESH_CHAT_UUID")

                while (isActive) {
                    val socket = try {
                        serverSocket?.accept()
                    } catch (e: Exception) {
                        null
                    }

                    if (socket != null) {
                        val peerAddress = socket.remoteDevice?.address ?: UUID.randomUUID().toString()
                        val peerName = try { socket.remoteDevice?.name ?: "Mesh Peer" } catch (e: SecurityException) { "Mesh Peer" }
                        Log.d(TAG, "Accepted RFCOMM connection from $peerName ($peerAddress)")

                        activeSockets[peerAddress] = socket
                        updatePeerConnectionState(peerAddress, peerName, true)
                        listenToSocket(socket, peerAddress)
                    }
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException starting RFCOMM server: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Error in RFCOMM server: ${e.message}")
            } finally {
                _isServerRunning.value = false
            }
        }
    }

    // --- Connect to Peer via RFCOMM ---
    @SuppressLint("MissingPermission")
    fun connectToPeer(peerId: String, peerName: String) {
        if (_useSimulator.value) {
            updatePeerConnectionState(peerId, peerName, true)
            return
        }

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) return

        scope.launch {
            try {
                val device = bluetoothAdapter.getRemoteDevice(peerId)
                bluetoothAdapter.cancelDiscovery()
                val socket = device.createRfcommSocketToServiceRecord(MESH_CHAT_UUID)
                socket.connect()

                activeSockets[peerId] = socket
                updatePeerConnectionState(peerId, peerName, true)

                val handshake = MeshPacket(
                    type = PacketType.HANDSHAKE,
                    senderId = "ME",
                    senderName = "Local User",
                    targetId = peerId,
                    threadId = peerId,
                    payload = "Mesh handshaking"
                )
                sendPacketOverSocket(socket, handshake)

                listenToSocket(socket, peerId)
            } catch (e: Exception) {
                Log.e(TAG, "Failed connection to $peerId: ${e.message}")
                updatePeerConnectionState(peerId, peerName, false)
            }
        }
    }

    private fun listenToSocket(socket: BluetoothSocket, peerId: String) {
        scope.launch {
            try {
                val reader = BufferedReader(InputStreamReader(socket.inputStream))
                while (isActive && socket.isConnected) {
                    val line = reader.readLine() ?: break
                    val packet = MeshPacket.fromJson(line)
                    if (packet != null) {
                        _packetsReceived.update { it + 1 }
                        _incomingPackets.emit(packet)

                        // Auto-acknowledge real chat payloads so the sender's message
                        // status reflects genuine delivery instead of staying stuck.
                        if (packet.type in setOf(
                                PacketType.CHAT_TEXT, PacketType.CHAT_IMAGE,
                                PacketType.LOCATION_SHARE, PacketType.SOS_BROADCAST,
                                PacketType.FILE_TRANSFER
                            )
                        ) {
                            val ack = MeshPacket(
                                type = PacketType.DELIVERY_ACK,
                                senderId = "ME",
                                senderName = "Local User",
                                targetId = packet.senderId,
                                threadId = packet.threadId,
                                payload = packet.packetId
                            )
                            sendPacketOverSocket(socket, ack)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Socket reader closed for $peerId")
            } finally {
                activeSockets.remove(peerId)
                updatePeerConnectionState(peerId, "Mesh Peer", false)
            }
        }
    }

    // --- Send Packet ---
    fun sendPacket(packet: MeshPacket) {
        _packetsSent.update { it + 1 }

        if (_useSimulator.value) {
            handleSimulatorTransmission(packet)
            return
        }

        if (activeSockets.isEmpty()) {
            Log.w(TAG, "No active Bluetooth connections -- message NOT sent (was previously faked as delivered here)")
            return
        }

        val socket = activeSockets[packet.targetId]
        if (socket != null && socket.isConnected) {
            sendPacketOverSocket(socket, packet)
        } else {
            activeSockets.values.forEach { s ->
                sendPacketOverSocket(s, packet)
            }
        }
    }

    private fun sendPacketOverSocket(socket: BluetoothSocket, packet: MeshPacket) {
        scope.launch {
            try {
                val writer = OutputStreamWriter(socket.outputStream)
                writer.write(packet.toJson() + "\n")
                writer.flush()
            } catch (e: Exception) {
                Log.e(TAG, "Error sending packet over socket: ${e.message}")
            }
        }
    }

    private fun updatePeerConnectionState(peerId: String, name: String, isConnected: Boolean) {
        _connectedPeersMap.update { current ->
            val updated = current.toMutableMap()
            if (isConnected) {
                updated[peerId] = PeerEntity(
                    peerId = peerId,
                    name = name,
                    statusMessage = "Connected via RFCOMM",
                    isConnected = true,
                    signalDbm = -55,
                    distanceMeters = 1.8f
                )
            } else {
                updated.remove(peerId)
            }
            updated
        }
    }

    // --- MESH ENGINE ---
    private fun initSimulatedPeers() {
        _discoveredPeers.value = emptyList()
        _connectedPeersMap.value = emptyMap()
    }

    private fun simulateScan() {
        _isDiscovering.value = true
        scope.launch {
            delay(1500)
            _isDiscovering.value = false
        }
    }

    private fun startSimulatorEngine() {
        // No-op for real open source bluetooth mesh app
    }

    private fun handleSimulatorTransmission(packet: MeshPacket) {
        scope.launch {
            delay(100)
            // Emit delivery ACK so outgoing message marks as delivered locally
            val ack = MeshPacket(
                type = PacketType.DELIVERY_ACK,
                senderId = packet.targetId,
                senderName = "Peer Node",
                targetId = packet.senderId,
                threadId = packet.threadId,
                payload = packet.packetId
            )
            _incomingPackets.emit(ack)
        }
    }

    private fun registerBluetoothReceiver() {
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_FOUND)
        }
        val receiver = object : BroadcastReceiver() {
            @SuppressLint("MissingPermission")
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    BluetoothAdapter.ACTION_STATE_CHANGED -> {
                        val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                        val enabled = state == BluetoothAdapter.STATE_ON
                        _isBluetoothEnabled.value = enabled
                        if (enabled) {
                            startRfcommServer()
                            loadBondedDevices()
                        }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                        _isDiscovering.value = true
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        _isDiscovering.value = false
                    }
                    BluetoothDevice.ACTION_FOUND -> {
                        val device: BluetoothDevice? =
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                            } else {
                                @Suppress("DEPRECATION")
                                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                            }
                        if (device != null) {
                            val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                            val peer = PeerEntity(
                                peerId = device.address ?: UUID.randomUUID().toString(),
                                name = try { device.name ?: "Discovered Peer" } catch (e: SecurityException) { "Discovered Peer" },
                                statusMessage = "Discovered via Bluetooth Scan",
                                signalDbm = if (rssi != Short.MIN_VALUE.toInt()) rssi else -68,
                                distanceMeters = calculateDistance(rssi),
                                lastSeenTimestamp = System.currentTimeMillis()
                            )
                            _discoveredPeers.update { current ->
                                (current + peer).distinctBy { it.peerId }
                            }
                        }
                    }
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
    }

    private fun calculateDistance(rssi: Int): Float {
        if (rssi == Short.MIN_VALUE.toInt() || rssi == 0) return 5.0f
        val txPower = -59
        val ratio = (txPower - rssi) / 20.0
        return Math.pow(10.0, ratio).toFloat().coerceIn(0.5f, 50.0f)
    }
}
