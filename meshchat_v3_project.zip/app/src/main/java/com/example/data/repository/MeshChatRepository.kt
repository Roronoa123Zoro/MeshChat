package com.example.data.repository

import android.content.Context
import com.example.data.bluetooth.BluetoothManagerService
import com.example.data.bluetooth.MeshPacket
import com.example.data.bluetooth.PacketType
import com.example.data.db.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MeshChatRepository(
    context: Context,
    private val database: AppDatabase = AppDatabase.getInstance(context),
    val bluetoothService: BluetoothManagerService = BluetoothManagerService(context)
) {
    private val dao = database.chatDao()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    val allThreads: Flow<List<ChatThreadEntity>> = dao.getAllThreads()
    val allPeers: Flow<List<PeerEntity>> = dao.getAllPeers()
    val userProfile: Flow<UserProfileEntity?> = dao.getUserProfile()

    val isBluetoothEnabled = bluetoothService.isBluetoothEnabled
    val isDiscovering = bluetoothService.isDiscovering
    val useSimulator = bluetoothService.useSimulator
    val connectedPeers = bluetoothService.connectedPeers
    val discoveredPeers = bluetoothService.discoveredPeers
    val packetsSent = bluetoothService.packetsSent
    val packetsReceived = bluetoothService.packetsReceived

    init {
        initDefaultThreadsAndProfile()
        observeIncomingPackets()
        syncDiscoveredPeersToDb()
    }

    private fun initDefaultThreadsAndProfile() {
        scope.launch {
            // Clean up any fake legacy peers or threads from prior database seeds
            dao.deleteThread("thread_PEER_ELENA_01")
            dao.deleteMessagesForThread("thread_PEER_ELENA_01")
            dao.deletePeers(listOf("PEER_ELENA_01", "PEER_MARCUS_02", "PEER_RESCUE_03", "PEER_SARAH_04"))

            // Ensure default profile exists
            val existingProfile = dao.getUserProfile().firstOrNull()
            if (existingProfile == null) {
                val deviceModel = android.os.Build.MODEL.ifBlank { "Android Node" }
                dao.saveUserProfile(
                    UserProfileEntity(
                        userId = "local_user_1",
                        name = deviceModel,
                        statusMessage = "Offline Bluetooth Mesh Active",
                        avatarColorHex = "#0284C7",
                        meshNodeId = "NODE-${(1000..9999).random()}"
                    )
                )
            }

            // Ensure default broadcast SOS thread exists
            val existingThreads = dao.getAllThreads().firstOrNull() ?: emptyList()
            if (existingThreads.isEmpty()) {
                val broadcastThread = ChatThreadEntity(
                    threadId = "thread_broadcast_sos",
                    peerId = "BROADCAST",
                    title = "🚨 Emergency Mesh SOS Broadcast",
                    avatarColorHex = "#EF4444",
                    lastMessageText = "Mesh Broadcast Channel open for all surrounding nodes.",
                    lastMessageTimestamp = System.currentTimeMillis(),
                    isBroadcastThread = true
                )
                dao.insertThread(broadcastThread)
            }
        }
    }

    private fun observeIncomingPackets() {
        scope.launch {
            bluetoothService.incomingPackets.collect { packet ->
                when (packet.type) {
                    PacketType.DELIVERY_ACK -> {
                        // Update message status to DELIVERED
                        dao.updateMessageStatus(packet.payload, MessageStatus.DELIVERED)
                    }
                    PacketType.CHAT_TEXT, PacketType.CHAT_IMAGE, PacketType.SOS_BROADCAST, PacketType.LOCATION_SHARE, PacketType.FILE_TRANSFER -> {
                        handleIncomingChatMessage(packet)
                    }
                    PacketType.HANDSHAKE -> {
                        val peer = PeerEntity(
                            peerId = packet.senderId,
                            name = packet.senderName,
                            statusMessage = "Active Peer Node",
                            isConnected = true,
                            lastSeenTimestamp = System.currentTimeMillis()
                        )
                        dao.insertPeer(peer)
                    }
                    else -> {}
                }
            }
        }
    }

    private suspend fun handleIncomingChatMessage(packet: MeshPacket) {
        val messageType = when (packet.type) {
            PacketType.CHAT_IMAGE -> MessageType.IMAGE_CANVAS
            PacketType.SOS_BROADCAST -> MessageType.SOS_BROADCAST
            PacketType.LOCATION_SHARE -> MessageType.LOCATION_PING
            PacketType.FILE_TRANSFER -> MessageType.FILE_ATTACHMENT
            else -> MessageType.TEXT
        }

        var processedExtraData = packet.extraData
        if ((messageType == MessageType.FILE_ATTACHMENT || messageType == MessageType.IMAGE_CANVAS) && !processedExtraData.isNullOrBlank()) {
            try {
                val json = org.json.JSONObject(processedExtraData)
                val fileName = json.optString("fileName", if (messageType == MessageType.IMAGE_CANVAS) "drawing_${System.currentTimeMillis()}.png" else "received_file")
                if (json.has("base64Data")) {
                    val base64Str = json.getString("base64Data")
                    val bytes = android.util.Base64.decode(base64Str, android.util.Base64.DEFAULT)
                    val savedFile = com.example.util.FileUtil.saveBytesToDownloads(bytes, fileName)
                    if (savedFile != null) {
                        json.put("uriString", android.net.Uri.fromFile(savedFile).toString())
                        json.remove("base64Data")
                        processedExtraData = json.toString()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val threadId = if (packet.targetId == "BROADCAST") "thread_broadcast_sos" else "thread_${packet.senderId}"

        // Ensure thread exists
        val existingThread = dao.getThreadById(threadId)
        if (existingThread == null) {
            val newThread = ChatThreadEntity(
                threadId = threadId,
                peerId = packet.senderId,
                title = packet.senderName,
                avatarColorHex = "#3B82F6",
                lastMessageText = packet.payload,
                lastMessageTimestamp = packet.timestamp,
                unreadCount = 1
            )
            dao.insertThread(newThread)
        } else {
            dao.updateThreadLastMessage(
                threadId = threadId,
                text = packet.payload,
                timestamp = packet.timestamp,
                unreadCount = existingThread.unreadCount + 1
            )
        }

        val incomingMsg = MessageEntity(
            messageId = packet.packetId,
            threadId = threadId,
            senderId = packet.senderId,
            senderName = packet.senderName,
            recipientId = "ME",
            content = packet.payload,
            timestamp = packet.timestamp,
            status = MessageStatus.DELIVERED,
            messageType = messageType,
            extraData = processedExtraData,
            isOutgoing = false
        )
        dao.insertMessage(incomingMsg)
    }

    private fun syncDiscoveredPeersToDb() {
        scope.launch {
            bluetoothService.discoveredPeers.collect { peers ->
                if (peers.isNotEmpty()) {
                    dao.insertPeers(peers)
                }
            }
        }
    }

    fun getMessagesForThread(threadId: String): Flow<List<MessageEntity>> {
        return dao.getMessagesForThread(threadId)
    }

    suspend fun sendMessage(
        threadId: String,
        recipientId: String,
        content: String,
        messageType: MessageType = MessageType.TEXT,
        extraData: String? = null
    ) {
        val user = dao.getUserProfile().firstOrNull()
        val senderName = user?.name ?: "Local User"
        val senderId = "ME"
        val messageId = "msg_${UUID.randomUUID().toString().take(8)}"
        val now = System.currentTimeMillis()

        val outgoingMsg = MessageEntity(
            messageId = messageId,
            threadId = threadId,
            senderId = senderId,
            senderName = senderName,
            recipientId = recipientId,
            content = content,
            timestamp = now,
            status = MessageStatus.TRANSMITTING,
            messageType = messageType,
            extraData = extraData,
            isOutgoing = true
        )
        dao.insertMessage(outgoingMsg)

        // Update thread
        val threadText = when (messageType) {
            MessageType.IMAGE_CANVAS -> "🎨 [Canvas Drawing]"
            MessageType.SOS_BROADCAST -> "🚨 [SOS Broadcast] $content"
            MessageType.LOCATION_PING -> "📍 [Location Coordinates]"
            MessageType.FILE_ATTACHMENT -> "📁 [File] $content"
            else -> content
        }

        val thread = dao.getThreadById(threadId)
        if (thread != null) {
            dao.updateThreadLastMessage(threadId, threadText, now, 0)
        } else {
            dao.insertThread(
                ChatThreadEntity(
                    threadId = threadId,
                    peerId = recipientId,
                    title = if (recipientId == "BROADCAST") "🚨 Emergency Mesh SOS Broadcast" else "Peer ($recipientId)",
                    lastMessageText = threadText,
                    lastMessageTimestamp = now
                )
            )
        }

        // Convert to MeshPacket and transmit
        val packetType = when (messageType) {
            MessageType.IMAGE_CANVAS -> PacketType.CHAT_IMAGE
            MessageType.SOS_BROADCAST -> PacketType.SOS_BROADCAST
            MessageType.LOCATION_PING -> PacketType.LOCATION_SHARE
            MessageType.FILE_ATTACHMENT -> PacketType.FILE_TRANSFER
            else -> PacketType.CHAT_TEXT
        }

        val packet = MeshPacket(
            packetId = messageId,
            type = packetType,
            senderId = senderId,
            senderName = senderName,
            targetId = recipientId,
            threadId = threadId,
            payload = content,
            timestamp = now,
            extraData = extraData
        )

        bluetoothService.sendPacket(packet)
    }

    suspend fun getThreadById(threadId: String): ChatThreadEntity? {
        return dao.getThreadById(threadId)
    }

    suspend fun togglePinThreads(threadIds: List<String>) {
        if (threadIds.isEmpty()) return
        val threads = threadIds.mapNotNull { dao.getThreadById(it) }
        val allPinned = threads.isNotEmpty() && threads.all { it.isPinned }
        val newPinState = !allPinned
        dao.updateThreadsPinStatus(threadIds, newPinState)
    }

    suspend fun getMessagesForThreadOnce(threadId: String): List<MessageEntity> {
        return dao.getMessagesOnceForThread(threadId)
    }

    suspend fun markThreadRead(threadId: String) {
        dao.markThreadRead(threadId)
    }

    suspend fun deleteThreads(threadIds: List<String>) {
        if (threadIds.isEmpty()) return
        dao.deleteMessagesForThreads(threadIds)
        dao.deleteThreads(threadIds)
    }

    suspend fun saveUserProfile(profile: UserProfileEntity) {
        dao.saveUserProfile(profile)
    }

    fun toggleSimulator(enabled: Boolean) {
        bluetoothService.setSimulatorEnabled(enabled)
    }

    fun startBluetoothDiscovery() {
        bluetoothService.startDiscovery()
    }

    fun connectToPeer(peerId: String, peerName: String) {
        scope.launch {
            // Ensure thread exists in Room
            val threadId = "thread_$peerId"
            val existing = dao.getThreadById(threadId)
            if (existing == null) {
                dao.insertThread(
                    ChatThreadEntity(
                        threadId = threadId,
                        peerId = peerId,
                        title = peerName,
                        avatarColorHex = "#3B82F6",
                        lastMessageText = "Tap to start offline Bluetooth chat",
                        lastMessageTimestamp = System.currentTimeMillis()
                    )
                )
            }
            bluetoothService.connectToPeer(peerId, peerName)
        }
    }
}
