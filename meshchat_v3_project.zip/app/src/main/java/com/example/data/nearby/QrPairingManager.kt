package com.example.data.nearby

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * QR Code Pairing Manager enabling out-of-band direct P2P pairing via camera QR scan.
 * Encodes local endpoint ID and alias into JSON QR bitmaps and parses scanned payloads
 * to immediately trigger Nearby Connection requests bypassing ambient discovery delays.
 */
class QrPairingManager(
    private val nearbyConnectionManager: NearbyConnectionManager
) {
    companion object {
        private const val TAG = "QrPairingManager"
    }

    /**
     * Generate a QR Code Bitmap encoding device pairing metadata string in JSON format:
     * {"id":"<ENDPOINT_ID>","alias":"<NAME>"}
     */
    suspend fun generateDeviceQrBitmap(
        endpointId: String,
        endpointName: String,
        size: Int = 512
    ): Bitmap = withContext(Dispatchers.Default) {
        val json = JSONObject().apply {
            put("id", endpointId)
            put("alias", endpointName)
        }
        val qrContent = json.toString()

        val hints = mapOf(
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 1
        )

        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(qrContent, BarcodeFormat.QR_CODE, size, size, hints)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)

        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        bitmap
    }

    /**
     * Parse scanned QR Code JSON payload string and immediately request connection
     * to the target endpoint, bypassing ambient discovery delays.
     */
    fun parseQrAndConnect(qrDataJson: String): Boolean {
        return try {
            val json = JSONObject(qrDataJson)
            val endpointId = json.optString("id").ifBlank { json.optString("endpointId") }
            val alias = json.optString("alias").ifBlank { json.optString("endpointName", "Scanned Peer") }

            if (endpointId.isBlank()) {
                Log.e(TAG, "Failed to parse QR code: missing endpoint ID")
                return false
            }

            Log.i(TAG, "Scanned valid QR code for peer $alias ($endpointId). Initiating direct connection...")
            nearbyConnectionManager.requestConnection(endpointId, alias)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing QR code JSON payload: ${e.message}", e)
            false
        }
    }
}
