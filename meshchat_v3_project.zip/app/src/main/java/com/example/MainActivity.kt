package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Router
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MeshChatViewModel
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ChatListScreen
import com.example.ui.screens.MeshNetworkScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RadarDiscoveryScreen
import com.example.ui.theme.MyApplicationTheme

import com.example.system.BatteryOptimizationHelper
import com.example.system.MeshForegroundService
import com.example.ui.viewmodel.MeshSharedViewModel

enum class ScreenRoute {
    CHAT_LIST,
    CHAT_DETAIL,
    RADAR,
    NETWORK,
    PROFILE
}

class MainActivity : ComponentActivity() {

    private val viewModel: MeshChatViewModel by viewModels()
    private val sharedViewModel: MeshSharedViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Launch background foreground service and initialize mesh network
        MeshForegroundService.startService(this, "MeshChat is active and connected")
        sharedViewModel.initMeshNetwork()

        // Check battery optimization exemption
        if (!BatteryOptimizationHelper.isIgnoringBatteryOptimizations(this)) {
            try {
                startActivity(BatteryOptimizationHelper.getIgnoreBatteryOptimizationIntent(this))
            } catch (e: Exception) {
                // Ignore if prompt unsupported
            }
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MeshChatApp(viewModel)
                }
            }
        }
    }
}

@Composable
fun MeshChatApp(viewModel: MeshChatViewModel) {
    var currentRoute by remember { mutableStateOf(ScreenRoute.CHAT_LIST) }

    val threads by viewModel.threads.collectAsStateWithLifecycle()
    val peers by viewModel.peers.collectAsStateWithLifecycle()
    val messages by viewModel.activeThreadMessages.collectAsStateWithLifecycle()
    val activeThread by viewModel.activeThread.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val isDiscovering by viewModel.isDiscovering.collectAsStateWithLifecycle()
    val useSimulator by viewModel.useSimulator.collectAsStateWithLifecycle()
    val packetsSent by viewModel.packetsSent.collectAsStateWithLifecycle()
    val packetsReceived by viewModel.packetsReceived.collectAsStateWithLifecycle()

    val showBottomNav = currentRoute != ScreenRoute.CHAT_DETAIL

    Scaffold(
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomNav) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentRoute == ScreenRoute.CHAT_LIST,
                        onClick = { currentRoute = ScreenRoute.CHAT_LIST },
                        icon = { Icon(Icons.Default.Chat, contentDescription = "Chats") },
                        label = { Text("Chats", fontWeight = if (currentRoute == ScreenRoute.CHAT_LIST) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_chats"),
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    NavigationBarItem(
                        selected = currentRoute == ScreenRoute.RADAR,
                        onClick = { currentRoute = ScreenRoute.RADAR },
                        icon = { Icon(Icons.Default.Radar, contentDescription = "Radar Discovery") },
                        label = { Text("Radar", fontWeight = if (currentRoute == ScreenRoute.RADAR) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_radar"),
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    NavigationBarItem(
                        selected = currentRoute == ScreenRoute.NETWORK,
                        onClick = { currentRoute = ScreenRoute.NETWORK },
                        icon = { Icon(Icons.Default.Router, contentDescription = "Mesh Network") },
                        label = { Text("Network", fontWeight = if (currentRoute == ScreenRoute.NETWORK) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_network"),
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    NavigationBarItem(
                        selected = currentRoute == ScreenRoute.PROFILE,
                        onClick = { currentRoute = ScreenRoute.PROFILE },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("Profile", fontWeight = if (currentRoute == ScreenRoute.PROFILE) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_profile"),
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentRoute) {
                ScreenRoute.CHAT_LIST -> {
                    val context = LocalContext.current
                    ChatListScreen(
                        threads = threads,
                        peers = peers,
                        isDiscovering = isDiscovering,
                        useSimulator = useSimulator,
                        onThreadSelected = { threadId ->
                            viewModel.selectThread(threadId)
                            currentRoute = ScreenRoute.CHAT_DETAIL
                        },
                        onDeleteThreads = { selectedIds ->
                            viewModel.deleteSelectedThreads(selectedIds)
                        },
                        onPinThreads = { selectedIds ->
                            viewModel.togglePinSelectedThreads(selectedIds)
                        },
                        onSaveAsPdf = { selectedIds ->
                            viewModel.exportSelectedThreadsToPdf(context, selectedIds) { count ->
                                if (count > 0) {
                                    Toast.makeText(
                                        context,
                                        "Saved $count chat PDF(s) to Download/MeshChat folder",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Failed to export chat as PDF",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        },
                        onStartDiscovery = { viewModel.scanNearbyPeers() },
                        onConnectPeer = { peer ->
                            viewModel.connectToPeer(peer)
                            currentRoute = ScreenRoute.CHAT_DETAIL
                        },
                        onNavigateToRadar = { currentRoute = ScreenRoute.RADAR },
                        onNavigateToNetwork = { currentRoute = ScreenRoute.NETWORK },
                        onNavigateToProfile = { currentRoute = ScreenRoute.PROFILE },
                        onSendSos = {
                            viewModel.sendEmergencySOS("🚨 EMERGENCY SOS BROADCAST: Requesting mesh contact and assistance!")
                            viewModel.selectThread("thread_broadcast_sos")
                            currentRoute = ScreenRoute.CHAT_DETAIL
                        }
                    )
                }

                ScreenRoute.CHAT_DETAIL -> {
                    ChatDetailScreen(
                        thread = activeThread,
                        messages = messages,
                        onBackClick = { currentRoute = ScreenRoute.CHAT_LIST },
                        onSendMessage = { text -> viewModel.sendMessage(text) },
                        onSendCanvas = { base64 -> viewModel.sendCanvasDrawing(base64) },
                        onSendLocation = { viewModel.sendLocationPing() },
                        onSendSos = { sosText -> viewModel.sendEmergencySOS(sosText) },
                        onSendFile = { uri -> viewModel.sendFileAttachment(uri) },
                        onSendFiles = { uris -> viewModel.sendFileAttachments(uris) }
                    )
                }

                ScreenRoute.RADAR -> {
                    RadarDiscoveryScreen(
                        peers = peers,
                        isScanning = isDiscovering,
                        onBackClick = { currentRoute = ScreenRoute.CHAT_LIST },
                        onScanClick = { viewModel.scanNearbyPeers() },
                        onConnectPeer = { peer ->
                            viewModel.connectToPeer(peer)
                            currentRoute = ScreenRoute.CHAT_DETAIL
                        }
                    )
                }

                ScreenRoute.NETWORK -> {
                    MeshNetworkScreen(
                        packetsSent = packetsSent,
                        packetsReceived = packetsReceived,
                        connectedPeers = peers.filter { it.isConnected },
                        useSimulator = useSimulator,
                        onBackClick = { currentRoute = ScreenRoute.CHAT_LIST },
                        onToggleSimulator = { enabled -> viewModel.toggleSimulatorMode(enabled) },
                        onSendSos = {
                            viewModel.sendEmergencySOS("🚨 EMERGENCY MESH SOS BROADCAST from Network Panel")
                            viewModel.selectThread("thread_broadcast_sos")
                            currentRoute = ScreenRoute.CHAT_DETAIL
                        }
                    )
                }

                ScreenRoute.PROFILE -> {
                    ProfileScreen(
                        profile = userProfile,
                        onBackClick = { currentRoute = ScreenRoute.CHAT_LIST },
                        onSaveProfile = { name, status, avatarHex ->
                            viewModel.saveProfile(name, status, avatarHex)
                            currentRoute = ScreenRoute.CHAT_LIST
                        }
                    )
                }
            }
        }
    }
}

