package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.PeerEntity
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RadarView(
    peers: List<PeerEntity>,
    isScanning: Boolean,
    onPeerSelected: (PeerEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "RadarTransition")

    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SweepAngle"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseScale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(320.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E293B),
                        Color(0xFF0F172A)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = (size.width.coerceAtMost(size.height) / 2f) - 16.dp.toPx()

            val ringCount = 3
            for (i in 1..ringCount) {
                val radius = maxRadius * (i.toFloat() / ringCount)
                drawCircle(
                    color = Color(0x3338BDF8),
                    radius = radius,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }

            drawLine(
                color = Color(0x2238BDF8),
                start = Offset(center.x - maxRadius, center.y),
                end = Offset(center.x + maxRadius, center.y),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = Color(0x2238BDF8),
                start = Offset(center.x, center.y - maxRadius),
                end = Offset(center.x, center.y + maxRadius),
                strokeWidth = 1.dp.toPx()
            )

            if (isScanning) {
                drawCircle(
                    color = Color(0x1A0284C7),
                    radius = maxRadius * pulseScale,
                    center = center
                )
            }

            val sweepRad = Math.toRadians(sweepAngle.toDouble())
            val lineEnd = Offset(
                x = center.x + (maxRadius * cos(sweepRad)).toFloat(),
                y = center.y + (maxRadius * sin(sweepRad)).toFloat()
            )
            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(Color(0x000284C7), Color(0xFF38BDF8)),
                    start = center,
                    end = lineEnd
                ),
                start = center,
                end = lineEnd,
                strokeWidth = 2.5.dp.toPx()
            )

            drawCircle(
                color = Color(0xFF0EA5E9),
                radius = 8.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 3.dp.toPx(),
                center = center
            )
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val density = LocalDensity.current
            val maxRadiusPx = remember(maxWidth, maxHeight) {
                with(density) { (maxWidth.coerceAtMost(maxHeight) / 2f - 24.dp).toPx() }
            }
            val centerPx = remember(maxWidth, maxHeight) {
                with(density) { Offset(maxWidth.toPx() / 2f, maxHeight.toPx() / 2f) }
            }

            peers.forEach { peer ->
                val normalizedDist = ((peer.signalDbm + 35).toFloat() / -60f).coerceIn(0.15f, 0.9f)
                val radiusPx = maxRadiusPx * normalizedDist

                val angleDeg = (peer.peerId.hashCode() % 360).let { if (it < 0) it + 360 else it }
                val angleRad = Math.toRadians(angleDeg.toDouble())

                val peerX = centerPx.x + (radiusPx * cos(angleRad)).toFloat()
                val peerY = centerPx.y + (radiusPx * sin(angleRad)).toFloat()

                val dpX = with(density) { peerX.toDp() }
                val dpY = with(density) { peerY.toDp() }

                Box(
                    modifier = Modifier
                        .offset(x = dpX - 20.dp, y = dpY - 20.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (peer.isConnected) Color(0x3310B981) else Color(0x3338BDF8))
                        .clickable { onPeerSelected(peer) },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(
                                if (peer.isConnected) Color(0xFF10B981)
                                else Color(0xFF38BDF8)
                            )
                    )
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
        ) {
            Text(
                text = if (isScanning) "BLUETOOTH MESH RADAR SCANNING..." else "RADAR READY • ${peers.size} PEERS IN RANGE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.1.sp
                ),
                color = Color(0xFF94A3B8)
            )
        }
    }
}
