package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.db.ChatThreadEntity
import com.example.data.db.MessageEntity
import com.example.data.db.MessageStatus
import com.example.data.db.MessageType
import com.example.ui.components.DrawingCanvasDialog
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    thread: ChatThreadEntity?,
    messages: List<MessageEntity>,
    onBackClick: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSendCanvas: (String) -> Unit,
    onSendLocation: () -> Unit,
    onSendSos: (String) -> Unit,
    onSendFile: (Uri) -> Unit = {},
    onSendFiles: (List<Uri>) -> Unit = { uris -> uris.forEach { onSendFile(it) } }
) {
    var inputText by remember { mutableStateOf("") }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var showDrawingCanvas by remember { mutableStateOf(false) }
    var selectedFileForPreview by remember { mutableStateOf<MessageEntity?>(null) }
    val stagedAttachments = remember { mutableStateListOf<Uri>() }

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    val filteredMessages = remember(messages, searchQuery) {
        if (searchQuery.isBlank()) {
            messages
        } else {
            val q = searchQuery.trim().lowercase()
            messages.filter { msg ->
                msg.content.lowercase().contains(q) ||
                msg.senderName.lowercase().contains(q) ||
                (msg.extraData?.lowercase()?.contains(q) == true)
            }
        }
    }

    if (selectedFileForPreview != null) {
        FileViewerDialog(
            message = selectedFileForPreview!!,
            onDismiss = { selectedFileForPreview = null }
        )
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            stagedAttachments.addAll(uris)
        }
    }

    val listState = rememberLazyListState()

    // Auto-scroll to latest message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    if (showDrawingCanvas) {
        DrawingCanvasDialog(
            onDismiss = { showDrawingCanvas = false },
            onSendDrawing = { base64Png ->
                showDrawingCanvas = false
                onSendCanvas(base64Png)
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        TextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search message history...", style = MaterialTheme.typography.bodyMedium) },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("chat_search_input")
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (thread?.isBroadcastThread == true) Color(0xFFEF4444)
                                        else MaterialTheme.colorScheme.primary
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (thread?.isBroadcastThread == true) "🚨" else (thread?.title?.take(1) ?: "P"),
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = thread?.title ?: "Mesh Chat",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (thread?.isBroadcastThread == true) "Public Emergency Beacon" else "Direct Bluetooth Mesh Channel",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (isSearchActive) {
                                isSearchActive = false
                                searchQuery = ""
                            } else {
                                onBackClick()
                            }
                        },
                        modifier = Modifier.testTag("chat_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (isSearchActive) {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear Search")
                            }
                        }
                    } else {
                        IconButton(
                            onClick = { isSearchActive = true },
                            modifier = Modifier.testTag("toggle_search_button")
                        ) {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = "Search Messages",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = { filePickerLauncher.launch("*/*") },
                            modifier = Modifier.testTag("attach_file_topbar")
                        ) {
                            Icon(
                                Icons.Default.AttachFile,
                                contentDescription = "Attach File",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { showDrawingCanvas = true }) {
                            Icon(Icons.Default.Brush, contentDescription = "Draw Canvas Sketch", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Search Query Banner
            if (searchQuery.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Found ${filteredMessages.size} matching message${if (filteredMessages.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        TextButton(
                            onClick = { searchQuery = "" },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("Clear", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // Message List / Empty State
            if (searchQuery.isNotBlank() && filteredMessages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Messages Found",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No messages match '$searchQuery'",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedButton(onClick = { searchQuery = "" }) {
                            Text("Clear Filter")
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    var lastDateHeader = ""
                    filteredMessages.forEachIndexed { index, msg ->
                        val dateHeader = formatDateHeader(msg.timestamp)
                        if (dateHeader != lastDateHeader) {
                            lastDateHeader = dateHeader
                            item(key = "header_${dateHeader}_$index") {
                                DateHeaderChip(dateText = dateHeader)
                            }
                        }
                        item(key = msg.messageId) {
                            MessageBubbleItem(
                                message = msg,
                                searchQuery = searchQuery,
                                onOpenFile = { selectedFileForPreview = it }
                            )
                        }
                    }
                }
            }

            // Attachment Options Bar (if toggled)
            AnimatedVisibility(visible = showAttachmentMenu) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // File Share Option
                        AssistChip(
                            onClick = {
                                showAttachmentMenu = false
                                filePickerLauncher.launch("*/*")
                            },
                            label = { Text("Attach Files") },
                            leadingIcon = { Icon(Icons.Default.AttachFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary) }
                        )

                        // Canvas Sketch Option
                        AssistChip(
                            onClick = {
                                showAttachmentMenu = false
                                showDrawingCanvas = true
                            },
                            label = { Text("Sketch") },
                            leadingIcon = { Icon(Icons.Default.Brush, contentDescription = null) }
                        )

                        // Location Ping Option
                        AssistChip(
                            onClick = {
                                showAttachmentMenu = false
                                onSendLocation()
                            },
                            label = { Text("Location") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) }
                        )

                        // Emergency SOS Ping Option
                        AssistChip(
                            onClick = {
                                showAttachmentMenu = false
                                onSendSos("🚨 Mesh Beacon Ping from Chat")
                            },
                            label = { Text("SOS") },
                            leadingIcon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444)) }
                        )
                    }
                }
            }

            // Input Bar
            Surface(
                tonalElevation = 4.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom))
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Staged Attachments Preview Strip
                    AnimatedVisibility(visible = stagedAttachments.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Attached Files (${stagedAttachments.size})",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                TextButton(
                                    onClick = { stagedAttachments.clear() },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                    modifier = Modifier.height(24.dp)
                                ) {
                                    Text(
                                        text = "Clear All",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                items(stagedAttachments) { uri ->
                                    val context = LocalContext.current
                                    val fileName = remember(uri) { getFileNameFromUri(context, uri) }
                                    val imageBitmap = remember(uri) { loadBitmapFromUri(context, uri.toString(), maxWidth = 200) }

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                        tonalElevation = 2.dp
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                        ) {
                                            if (imageBitmap != null) {
                                                Image(
                                                    bitmap = imageBitmap.asImageBitmap(),
                                                    contentDescription = fileName,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(RoundedCornerShape(6.dp))
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.InsertDriveFile,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                            }

                                            Text(
                                                text = fileName,
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.widthIn(max = 120.dp)
                                            )

                                            Spacer(modifier = Modifier.width(4.dp))

                                            IconButton(
                                                onClick = { stagedAttachments.remove(uri) },
                                                modifier = Modifier.size(20.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "Remove attachment",
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Main Text & Actions Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showAttachmentMenu = !showAttachmentMenu },
                            modifier = Modifier.testTag("attachment_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Attachments",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        TextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = {
                                Text(
                                    if (stagedAttachments.isNotEmpty()) "Add a message with attached files..."
                                    else "Write offline message..."
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_textfield"),
                            shape = RoundedCornerShape(24.dp),
                            colors = TextFieldDefaults.colors(
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        val canSend = inputText.isNotBlank() || stagedAttachments.isNotEmpty()

                        IconButton(
                            onClick = {
                                val textToSend = inputText.trim()
                                val filesToSend = stagedAttachments.toList()

                                if (textToSend.isNotBlank()) {
                                    onSendMessage(textToSend)
                                    inputText = ""
                                }
                                if (filesToSend.isNotEmpty()) {
                                    onSendFiles(filesToSend)
                                    stagedAttachments.clear()
                                }
                            },
                            enabled = canSend,
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (canSend) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag("send_message_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Message")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubbleItem(
    message: MessageEntity,
    searchQuery: String = "",
    onOpenFile: (MessageEntity) -> Unit = {}
) {
    val context = LocalContext.current
    val isOutgoing = message.isOutgoing

    fun copyMessageText() {
        val textToCopy = if (message.messageType == MessageType.FILE_ATTACHMENT) {
            "File: ${message.content}"
        } else {
            message.content
        }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Mesh Message", textToCopy)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied text to clipboard", Toast.LENGTH_SHORT).show()
    }

    val bubbleColor = if (isOutgoing) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surfaceContainerHigh
    }

    val contentColor = if (isOutgoing) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    val alignment = if (isOutgoing) Alignment.End else Alignment.Start

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalAlignment = alignment
    ) {
        if (!isOutgoing) {
            val annotatedSender = buildHighlightedAnnotatedString(
                text = message.senderName,
                query = searchQuery,
                highlightBg = Color(0xFFFFD54F),
                highlightText = Color(0xFF0F172A)
            )
            Text(
                text = annotatedSender,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 12.dp, bottom = 2.dp)
            )
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isOutgoing) 20.dp else 4.dp,
                bottomEnd = if (isOutgoing) 4.dp else 20.dp
            ),
            color = if (message.messageType == MessageType.SOS_BROADCAST) MaterialTheme.colorScheme.errorContainer else bubbleColor,
            contentColor = if (message.messageType == MessageType.SOS_BROADCAST) MaterialTheme.colorScheme.onErrorContainer else contentColor,
            tonalElevation = if (isOutgoing) 2.dp else 1.dp,
            modifier = Modifier
                .widthIn(max = 290.dp)
                .combinedClickable(
                    onClick = {
                        if (message.messageType == MessageType.IMAGE_CANVAS || message.messageType == MessageType.FILE_ATTACHMENT) {
                            onOpenFile(message)
                        }
                    },
                    onLongClick = {
                        copyMessageText()
                    }
                )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {

                // Render Canvas Sketch Image Attachment
                if (message.messageType == MessageType.IMAGE_CANVAS && !message.extraData.isNullOrEmpty()) {
                    val bitmap = remember(message.extraData) {
                        try {
                            if (message.extraData.startsWith("{")) {
                                val json = JSONObject(message.extraData)
                                if (json.has("base64Data")) {
                                    val decodedBytes = Base64.decode(json.getString("base64Data"), Base64.DEFAULT)
                                    BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                                } else null
                            } else {
                                val decodedBytes = Base64.decode(message.extraData, Base64.DEFAULT)
                                BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                            }
                        } catch (e: Exception) {
                            null
                        }
                    }

                    if (bitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0F172A))
                                .clickable { onOpenFile(message) }
                        ) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Canvas Sketch",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(4.dp)
                            )
                            Surface(
                                color = Color.Black.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ZoomIn,
                                        contentDescription = "View Full Screen",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Full View",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }

                // Render SOS Alert header
                if (message.messageType == MessageType.SOS_BROADCAST) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "EMERGENCY MESH BEACON",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFFEF4444)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Render Location Pin header
                if (message.messageType == MessageType.LOCATION_PING) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "MESH GPS COORDINATES",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF38BDF8)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Render File Attachment
                if (message.messageType == MessageType.FILE_ATTACHMENT) {
                    FileAttachmentCard(
                        message = message,
                        isOutgoing = isOutgoing,
                        searchQuery = searchQuery,
                        onOpenFile = { onOpenFile(message) }
                    )
                } else {
                    // Message Text
                    val annotatedContent = buildHighlightedAnnotatedString(
                        text = message.content,
                        query = searchQuery,
                        highlightBg = if (isOutgoing) Color(0xFFFDE047) else Color(0xFFFFD54F),
                        highlightText = Color(0xFF0F172A)
                    )
                    SelectionContainer {
                        Text(
                            text = annotatedContent,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Time, Copy Button & Status Indicators
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val formattedTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(message.timestamp))
                    val timeLabel = if (isOutgoing) "Sent $formattedTime" else "Received $formattedTime"

                    Text(
                        text = timeLabel,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Medium),
                        color = if (isOutgoing) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Copy Text Icon Button
                    IconButton(
                        onClick = { copyMessageText() },
                        modifier = Modifier.size(18.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy message text",
                            tint = if (isOutgoing) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                            modifier = Modifier.size(11.dp)
                        )
                    }

                    if (isOutgoing) {
                        Spacer(modifier = Modifier.width(4.dp))
                        when (message.status) {
                            MessageStatus.TRANSMITTING -> {
                                Icon(
                                    imageVector = Icons.Default.Router,
                                    contentDescription = "Transmitting",
                                    tint = Color.White.copy(alpha = 0.85f),
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                            MessageStatus.DELIVERED -> {
                                Icon(
                                    imageVector = Icons.Default.DoneAll,
                                    contentDescription = "Delivered",
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            else -> {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Sent",
                                    tint = Color.White.copy(alpha = 0.85f),
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DateHeaderChip(dateText: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        ) {
            Text(
                text = dateText,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
    }
}

fun formatDateHeader(timestamp: Long): String {
    val messageDate = Date(timestamp)
    val now = Date()
    val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.getDefault())

    val messageDateStr = dateFormat.format(messageDate)
    val nowDateStr = dateFormat.format(now)

    val yesterday = Date(now.time - 24 * 60 * 60 * 1000)
    val yesterdayDateStr = dateFormat.format(yesterday)

    return when (messageDateStr) {
        nowDateStr -> "Today"
        yesterdayDateStr -> "Yesterday"
        else -> SimpleDateFormat("EEEE, MMM d, yyyy", Locale.getDefault()).format(messageDate)
    }
}

@Composable
fun FileAttachmentCard(
    message: MessageEntity,
    isOutgoing: Boolean,
    searchQuery: String = "",
    onOpenFile: () -> Unit
) {
    val context = LocalContext.current
    var fileName = message.content
    var formattedSize = "Mesh Attachment"
    var mimeType = ""
    var fileExtension = ""
    var uriString = ""

    if (!message.extraData.isNullOrBlank()) {
        try {
            val json = JSONObject(message.extraData)
            if (json.has("fileName")) fileName = json.getString("fileName")
            if (json.has("formattedSize")) formattedSize = json.getString("formattedSize")
            if (json.has("mimeType")) mimeType = json.getString("mimeType")
            if (json.has("fileExtension")) fileExtension = json.getString("fileExtension")
            if (json.has("uriString")) uriString = json.getString("uriString")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    if (fileExtension.isBlank() && fileName.contains('.')) {
        fileExtension = fileName.substringAfterLast('.').lowercase()
    }

    val isImage = fileExtension in listOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg") || mimeType.startsWith("image/")
    val isText = fileExtension in listOf("txt", "log", "json", "xml", "kt", "java", "py", "js", "ts", "html", "css", "csv", "md") || mimeType.startsWith("text/")

    val (icon, iconColor) = when {
        isImage -> Icons.Default.Image to Color(0xFF10B981)
        fileExtension in listOf("mp3", "wav", "flac", "m4a", "ogg") || mimeType.startsWith("audio/") ->
            Icons.Default.AudioFile to Color(0xFFF59E0B)
        fileExtension in listOf("mp4", "mkv", "avi", "mov", "webm") || mimeType.startsWith("video/") ->
            Icons.Default.VideoFile to Color(0xFFEC4899)
        fileExtension in listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx") ->
            Icons.Default.Description to Color(0xFFEF4444)
        fileExtension in listOf("zip", "rar", "7z", "tar", "gz") ->
            Icons.Default.FolderZip to Color(0xFF8B5CF6)
        isText -> Icons.Default.Code to Color(0xFF0EA5E9)
        else -> Icons.Default.AttachFile to Color(0xFF3B82F6)
    }

    val imageBitmap = remember(uriString) {
        if (isImage && uriString.isNotBlank()) {
            loadBitmapFromUri(context, uriString, maxWidth = 600)
        } else null
    }

    val textSnippet = remember(uriString) {
        if (isText && uriString.isNotBlank()) {
            loadTextPreviewFromUri(context, uriString, maxLines = 5)
        } else null
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        // Render Image Thumbnail if available
        if (imageBitmap != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.2f))
                    .clickable { onOpenFile() }
            ) {
                Image(
                    bitmap = imageBitmap.asImageBitmap(),
                    contentDescription = fileName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Preview", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Color.White))
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        } else if (!textSnippet.isNullOrBlank()) {
            // Render Text Snippet Preview
            val annotatedSnippet = buildHighlightedAnnotatedString(
                text = textSnippet!!,
                query = searchQuery,
                highlightBg = Color(0xFFFFD54F),
                highlightText = Color(0xFF0F172A)
            )
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenFile() }
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = annotatedSnippet,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = if (isOutgoing) Color.White.copy(alpha = 0.95f) else MaterialTheme.colorScheme.onSurface,
                        maxLines = 5,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tap to read full file...",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                        color = iconColor
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Header info row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onOpenFile() }
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(iconColor.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = "File Type",
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                val annotatedFileName = buildHighlightedAnnotatedString(
                    text = fileName,
                    query = searchQuery,
                    highlightBg = Color(0xFFFFD54F),
                    highlightText = Color(0xFF0F172A)
                )
                Text(
                    text = annotatedFileName,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (isOutgoing) Color.White else MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "$formattedSize • P2P Channel",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    color = if (isOutgoing) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Actions row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = iconColor.copy(alpha = 0.2f)
            ) {
                Text(
                    text = if (isOutgoing) "RFCOMM Stream" else "Mesh Channel",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.SemiBold),
                    color = iconColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Row {
                TextButton(
                    onClick = { onOpenFile() },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Text(
                        text = "Preview",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium, fontSize = 11.sp),
                        color = if (isOutgoing) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                TextButton(
                    onClick = {
                        val launched = openFileExternal(context, uriString, mimeType, fileName)
                        if (!launched) {
                            onOpenFile()
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Text(
                        text = "Open File",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                        color = if (isOutgoing) Color.White else MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileViewerDialog(
    message: MessageEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var fileName = message.content
    var formattedSize = "Mesh Attachment"
    var mimeType = ""
    var fileExtension = ""
    var uriString = ""

    if (!message.extraData.isNullOrBlank()) {
        try {
            val json = JSONObject(message.extraData)
            if (json.has("fileName")) fileName = json.getString("fileName")
            if (json.has("formattedSize")) formattedSize = json.getString("formattedSize")
            if (json.has("mimeType")) mimeType = json.getString("mimeType")
            if (json.has("fileExtension")) fileExtension = json.getString("fileExtension")
            if (json.has("uriString")) uriString = json.getString("uriString")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    if (fileExtension.isBlank() && fileName.contains('.')) {
        fileExtension = fileName.substringAfterLast('.').lowercase()
    }

    val isImage = message.messageType == MessageType.IMAGE_CANVAS || fileExtension in listOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg") || mimeType.startsWith("image/")
    val isText = fileExtension in listOf("txt", "log", "json", "xml", "kt", "java", "py", "js", "ts", "html", "css", "csv", "md") || mimeType.startsWith("text/")

    val canvasBitmap = remember(message) {
        if (message.messageType == MessageType.IMAGE_CANVAS && !message.extraData.isNullOrBlank()) {
            try {
                if (message.extraData.startsWith("{")) {
                    val json = JSONObject(message.extraData)
                    if (json.has("uriString")) {
                        val loaded = loadBitmapFromUri(context, json.getString("uriString"), maxWidth = 1600)
                        if (loaded != null) return@remember loaded
                    }
                    if (json.has("base64Data")) {
                        val bytes = Base64.decode(json.getString("base64Data"), Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    } else null
                } else {
                    val bytes = Base64.decode(message.extraData, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }
            } catch (e: Exception) {
                null
            }
        } else null
    }

    val fullImageBitmap = remember(uriString, canvasBitmap) {
        if (canvasBitmap != null) {
            canvasBitmap
        } else if (isImage && uriString.isNotBlank()) {
            loadBitmapFromUri(context, uriString, maxWidth = 1200)
        } else null
    }

    val fullTextContent = remember(uriString) {
        if (isText && uriString.isNotBlank()) {
            loadTextPreviewFromUri(context, uriString, maxLines = 500)
        } else null
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.InsertDriveFile,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = fileName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                text = "$formattedSize • ${mimeType.ifBlank { "File Attachment" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider()

                // Scrollable Content View
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    if (isImage && fullImageBitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = fullImageBitmap.asImageBitmap(),
                                contentDescription = fileName,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        }
                    } else if (isText && !fullTextContent.isNullOrBlank()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "File Content Viewer",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                TextButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("File Content", fullTextContent))
                                        Toast.makeText(context, "Copied text content to clipboard", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy Text")
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = fullTextContent!!,
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    } else {
                        // General File Metadata Inspector Card
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "📁 Shared File Details",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    DetailItem("File Name", fileName)
                                    DetailItem("File Size", formattedSize)
                                    DetailItem("Type", mimeType.ifBlank { fileExtension.uppercase() })
                                    DetailItem("Sender", message.senderName)
                                    DetailItem("Timestamp", SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault()).format(Date(message.timestamp)))
                                    DetailItem("Channel", if (message.isOutgoing) "Outbound RFCOMM Mesh Stream" else "Inbound P2P Peer Stream")
                                    if (uriString.isNotBlank()) {
                                        DetailItem("Local URI", uriString)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "💡 Tip: Tap 'Open in System App' to view or play this file using your device's default reader.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                HorizontalDivider()

                // Actions Footer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (uriString.isNotBlank()) {
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("File URI", uriString))
                                Toast.makeText(context, "Copied file path to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Path")
                        }

                        IconButton(
                            onClick = {
                                shareFileExternal(context, uriString, fileName)
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share File")
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val opened = openFileExternal(context, uriString, mimeType, fileName)
                            if (opened) onDismiss()
                        }
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open in System App")
                    }
                }
            }
        }
    }
}

@Composable
fun DetailItem(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

fun loadBitmapFromUri(context: Context, uriString: String?, maxWidth: Int = 800): Bitmap? {
    if (uriString.isNullOrBlank()) return null
    return try {
        val uri = Uri.parse(uriString)
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(stream, null, options)
            var sampleSize = 1
            if (options.outWidth > maxWidth || options.outHeight > maxWidth) {
                sampleSize = Math.max(options.outWidth / maxWidth, options.outHeight / maxWidth)
            }
            context.contentResolver.openInputStream(uri)?.use { stream2 ->
                val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                BitmapFactory.decodeStream(stream2, null, decodeOpts)
            }
        }
    } catch (e: Exception) {
        null
    }
}

fun loadTextPreviewFromUri(context: Context, uriString: String?, maxLines: Int = 100): String? {
    if (uriString.isNullOrBlank()) return null
    return try {
        val uri = Uri.parse(uriString)
        context.contentResolver.openInputStream(uri)?.use { stream ->
            stream.bufferedReader().useLines { lines ->
                lines.take(maxLines).joinToString("\n")
            }
        }
    } catch (e: Exception) {
        null
    }
}

fun openFileExternal(context: Context, uriString: String?, mimeType: String?, fileName: String): Boolean {
    return com.example.util.FileUtil.openFileInSystemApp(context, uriString, mimeType ?: "", fileName)
}

fun shareFileExternal(context: Context, uriString: String?, fileName: String) {
    if (uriString.isNullOrBlank()) {
        Toast.makeText(context, "Cannot share: file path is empty", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri = Uri.parse(uriString)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Share $fileName")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (e: Exception) {
        Toast.makeText(context, "Error sharing file: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}

fun getMimeTypeFromFileName(fileName: String): String {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    return when (ext) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "pdf" -> "application/pdf"
        "txt", "log" -> "text/plain"
        "json" -> "application/json"
        "html", "htm" -> "text/html"
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "mp4" -> "video/mp4"
        "zip" -> "application/zip"
        else -> "*/*"
    }
}

fun getFileNameFromUri(context: Context, uri: Uri): String {
    var fileName = "attachment"
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIdx != -1) {
                val queriedName = cursor.getString(nameIdx)
                if (!queriedName.isNullOrBlank()) fileName = queriedName
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return fileName
}

fun buildHighlightedAnnotatedString(
    text: String,
    query: String,
    highlightBg: Color = Color(0xFFFFD54F),
    highlightText: Color = Color(0xFF0F172A)
): AnnotatedString {
    val q = query.trim()
    if (q.isEmpty() || !text.contains(q, ignoreCase = true)) {
        return AnnotatedString(text)
    }

    return buildAnnotatedString {
        val lowerText = text.lowercase()
        val lowerQuery = q.lowercase()
        var startIndex = 0

        while (startIndex < text.length) {
            val index = lowerText.indexOf(lowerQuery, startIndex)
            if (index == -1) {
                append(text.substring(startIndex))
                break
            } else {
                if (index > startIndex) {
                    append(text.substring(startIndex, index))
                }
                val endIndex = index + q.length
                withStyle(
                    SpanStyle(
                        background = highlightBg,
                        color = highlightText,
                        fontWeight = FontWeight.Bold
                    )
                ) {
                    append(text.substring(index, endIndex))
                }
                startIndex = endIndex
            }
        }
    }
}
