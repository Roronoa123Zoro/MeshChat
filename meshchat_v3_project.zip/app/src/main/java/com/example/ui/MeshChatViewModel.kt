package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.ChatThreadEntity
import com.example.data.db.MessageEntity
import com.example.data.db.MessageType
import com.example.data.db.PeerEntity
import com.example.data.db.UserProfileEntity
import com.example.data.repository.MeshChatRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MeshChatViewModel(application: Application) : AndroidViewModel(application) {

    val repository = MeshChatRepository(application)

    val threads: StateFlow<List<ChatThreadEntity>> = repository.allThreads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val peers: StateFlow<List<PeerEntity>> = repository.allPeers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<UserProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isDiscovering: StateFlow<Boolean> = repository.isDiscovering
    val useSimulator: StateFlow<Boolean> = repository.useSimulator
    val packetsSent: StateFlow<Int> = repository.packetsSent
    val packetsReceived: StateFlow<Int> = repository.packetsReceived

    private val _activeThreadId = MutableStateFlow<String?>("thread_broadcast_sos")
    val activeThreadId: StateFlow<String?> = _activeThreadId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeThreadMessages: StateFlow<List<MessageEntity>> = _activeThreadId
        .flatMapLatest { threadId ->
            if (threadId != null) {
                repository.getMessagesForThread(threadId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeThread: StateFlow<ChatThreadEntity?> = combine(threads, _activeThreadId) { threadList, activeId ->
        threadList.firstOrNull { it.threadId == activeId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun selectThread(threadId: String) {
        _activeThreadId.value = threadId
        viewModelScope.launch {
            repository.markThreadRead(threadId)
        }
    }

    fun deleteSelectedThreads(threadIds: Set<String>) {
        if (threadIds.isEmpty()) return
        viewModelScope.launch {
            repository.deleteThreads(threadIds.toList())
            if (threadIds.contains(_activeThreadId.value)) {
                _activeThreadId.value = null
            }
        }
    }

    fun togglePinSelectedThreads(threadIds: Set<String>) {
        if (threadIds.isEmpty()) return
        viewModelScope.launch {
            repository.togglePinThreads(threadIds.toList())
        }
    }

    fun exportSelectedThreadsToPdf(
        context: android.content.Context,
        threadIds: Set<String>,
        onComplete: (Int) -> Unit
    ) {
        if (threadIds.isEmpty()) return
        viewModelScope.launch {
            var count = 0
            for (threadId in threadIds) {
                val thread = repository.getThreadById(threadId) ?: continue
                val messages = repository.getMessagesForThreadOnce(threadId)
                val file = com.example.util.PdfExporter.exportChatToPdf(context, thread, messages)
                if (file != null) {
                    count++
                }
            }
            onComplete(count)
        }
    }

    fun sendMessage(content: String) {
        if (content.isBlank()) return
        val currentThread = activeThread.value
        val threadId = currentThread?.threadId ?: _activeThreadId.value ?: return
        val recipientId = currentThread?.peerId ?: if (threadId == "thread_broadcast_sos") "BROADCAST" else threadId.removePrefix("thread_")

        viewModelScope.launch {
            repository.sendMessage(
                threadId = threadId,
                recipientId = recipientId,
                content = content.trim(),
                messageType = MessageType.TEXT
            )
        }
    }

    fun sendCanvasDrawing(base64Png: String) {
        val currentThread = activeThread.value
        val threadId = currentThread?.threadId ?: _activeThreadId.value ?: return
        val recipientId = currentThread?.peerId ?: if (threadId == "thread_broadcast_sos") "BROADCAST" else threadId.removePrefix("thread_")

        viewModelScope.launch {
            repository.sendMessage(
                threadId = threadId,
                recipientId = recipientId,
                content = "🎨 Canvas Drawing Attachment",
                messageType = MessageType.IMAGE_CANVAS,
                extraData = base64Png
            )
        }
    }

    fun sendEmergencySOS(sosMessage: String) {
        viewModelScope.launch {
            repository.sendMessage(
                threadId = "thread_broadcast_sos",
                recipientId = "BROADCAST",
                content = sosMessage.ifBlank { "🚨 EMERGENCY SOS: Requesting immediate mesh contact and assistance!" },
                messageType = MessageType.SOS_BROADCAST
            )
        }
    }

    fun sendLocationPing() {
        val currentThread = activeThread.value
        val threadId = currentThread?.threadId ?: _activeThreadId.value ?: return
        val recipientId = currentThread?.peerId ?: if (threadId == "thread_broadcast_sos") "BROADCAST" else threadId.removePrefix("thread_")

        viewModelScope.launch {
            repository.sendMessage(
                threadId = threadId,
                recipientId = recipientId,
                content = "📍 Shared Mesh GPS Ping: 37.7749° N, 122.4194° W",
                messageType = MessageType.LOCATION_PING,
                extraData = "37.7749,-122.4194"
            )
        }
    }

    fun sendFileAttachments(uris: List<android.net.Uri>) {
        uris.forEach { uri ->
            sendFileAttachment(uri)
        }
    }

    fun sendFileAttachment(uri: android.net.Uri) {
        val currentThread = activeThread.value
        val threadId = currentThread?.threadId ?: _activeThreadId.value ?: return
        val recipientId = currentThread?.peerId ?: if (threadId == "thread_broadcast_sos") "BROADCAST" else threadId.removePrefix("thread_")

        viewModelScope.launch {
            val app = getApplication<Application>()
            var fileName = "attachment_file"
            var fileSize = 0L
            var mimeType = app.contentResolver.getType(uri) ?: "application/octet-stream"

            try {
                app.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx != -1) {
                            val queriedName = cursor.getString(nameIdx)
                            if (!queriedName.isNullOrBlank()) fileName = queriedName
                        }
                        if (sizeIdx != -1) fileSize = cursor.getLong(sizeIdx)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Save file copy into Downloads/MeshChat
            val savedFile = com.example.util.FileUtil.copyUriToDownloads(app, uri, fileName)
            val fileUriString = if (savedFile != null) android.net.Uri.fromFile(savedFile).toString() else uri.toString()
            if (savedFile != null && savedFile.length() > 0) {
                fileSize = savedFile.length()
            }

            if (mimeType == "application/octet-stream" || mimeType.isBlank()) {
                mimeType = com.example.util.FileUtil.getMimeTypeFromFileName(fileName)
            }

            val formattedSize = formatFileSize(fileSize)
            val fileExtension = fileName.substringAfterLast('.', "").lowercase()

            val jsonObj = org.json.JSONObject().apply {
                put("fileName", fileName)
                put("fileSize", fileSize)
                put("formattedSize", formattedSize)
                put("mimeType", mimeType)
                put("fileExtension", fileExtension)
                put("uriString", fileUriString)
            }

            repository.sendMessage(
                threadId = threadId,
                recipientId = recipientId,
                content = fileName,
                messageType = MessageType.FILE_ATTACHMENT,
                extraData = jsonObj.toString()
            )
        }
    }

    private fun formatFileSize(size: Long): String {
        if (size <= 0) return "Unknown size"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
        return String.format(java.util.Locale.getDefault(), "%.1f %s", size / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }

    fun scanNearbyPeers() {
        repository.startBluetoothDiscovery()
    }

    fun connectToPeer(peer: PeerEntity) {
        repository.connectToPeer(peer.peerId, peer.name)
        val threadId = "thread_${peer.peerId}"
        selectThread(threadId)
    }

    fun toggleSimulatorMode(enabled: Boolean) {
        repository.toggleSimulator(enabled)
    }

    fun saveProfile(name: String, status: String, avatarHex: String) {
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfileEntity()
            val updated = current.copy(
                name = name.ifBlank { "Mesh Scout" },
                statusMessage = status.ifBlank { "Offline Active" },
                avatarColorHex = avatarHex
            )
            repository.saveUserProfile(updated)
        }
    }
}
