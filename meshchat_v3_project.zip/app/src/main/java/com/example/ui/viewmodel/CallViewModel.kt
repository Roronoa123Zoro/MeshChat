package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import com.example.data.MeshServiceLocator
import com.example.data.call.CallType
import com.example.data.call.VideoCallManager
import com.example.data.repository.CallRepository
import com.example.data.repository.CallState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/**
 * ViewModel managing P2P offline audio and video calling state, call negotiation actions
 * (initiate, accept, reject, end), and binding video stream frames to UI surfaces.
 */
class CallViewModel @JvmOverloads constructor(
    application: Application,
    private val callRepository: CallRepository = MeshServiceLocator.getCallRepository(application),
    private val videoCallManager: VideoCallManager = MeshServiceLocator.getVideoCallManager(application)
) : AndroidViewModel(application) {

    val callState: StateFlow<CallState> = callRepository.callState
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = CallState.Idle
        )

    val latestVideoFrame: StateFlow<ByteArray?> = videoCallManager.latestReceivedFrame
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    fun initiateCall(peerId: String, isVideo: Boolean) {
        val type = if (isVideo) CallType.VIDEO else CallType.AUDIO
        callRepository.initiateCall(peerId, type)
    }

    fun acceptCall(lifecycleOwner: LifecycleOwner? = null) {
        callRepository.acceptCall(lifecycleOwner)
    }

    fun rejectCall() {
        callRepository.rejectCall()
    }

    fun endCall() {
        callRepository.endCall()
    }

    fun startLocalVideoStream(lifecycleOwner: LifecycleOwner) {
        val currentState = callState.value
        if (currentState is CallState.InCall) {
            callRepository.startLocalVideoStream(currentState.peerId, lifecycleOwner)
        } else {
            videoCallManager.startVideoStream(lifecycleOwner)
        }
    }

    fun stopLocalVideoStream() {
        videoCallManager.stopVideoStream()
    }

    override fun onCleared() {
        super.onCleared()
        // Ensure call is cleaned up if viewmodel clears
        if (callState.value !is CallState.Idle) {
            callRepository.endCall()
        }
    }
}
