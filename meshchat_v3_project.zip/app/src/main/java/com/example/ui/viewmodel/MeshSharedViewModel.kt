package com.example.ui.viewmodel

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MeshServiceLocator
import com.example.data.nearby.NearbyConnectionManager
import com.example.data.nearby.Peer
import com.example.system.BatteryOptimizationHelper
import com.example.system.MeshForegroundService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/**
 * Shared ViewModel managing global application state, network initialization,
 * background foreground service activation, battery optimization exemptions,
 * and exposing connected peers for the Radar View.
 */
class MeshSharedViewModel @JvmOverloads constructor(
    application: Application,
    private val nearbyConnectionManager: NearbyConnectionManager = MeshServiceLocator.getNearbyConnectionManager(application)
) : AndroidViewModel(application) {

    val connectedPeers: StateFlow<List<Peer>> = nearbyConnectionManager.connectedPeers
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val isDiscovering: StateFlow<Boolean> = nearbyConnectionManager.isDiscovering
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false
        )

    val isAdvertising: StateFlow<Boolean> = nearbyConnectionManager.isAdvertising
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false
        )

    /**
     * Initializes the P2P Mesh Network: launches Foreground Service, verifies battery exemption,
     * and starts Nearby Connections advertising and discovery.
     */
    fun initMeshNetwork(username: String? = null) {
        val app = getApplication<Application>()
        
        // 1. Launch Foreground Service for un-killed background connectivity
        MeshForegroundService.startService(app, "MeshChat active and discovering nearby peers")

        // 2. Start Advertising and Discovery
        val localName = username ?: Build.MODEL.ifBlank { "Mesh Node" }
        nearbyConnectionManager.startAdvertising(localName)
        nearbyConnectionManager.startDiscovery()
    }

    /**
     * Checks if battery optimizations are ignored for MeshChat.
     */
    fun isBatteryOptimizationIgnored(): Boolean {
        return BatteryOptimizationHelper.isIgnoringBatteryOptimizations(getApplication())
    }

    /**
     * Stops mesh network operations and shuts down background foreground service.
     */
    fun stopMeshNetwork() {
        nearbyConnectionManager.stopAll()
        MeshForegroundService.stopService(getApplication())
    }

    override fun onCleared() {
        super.onCleared()
        // ViewModel cleared
    }
}
