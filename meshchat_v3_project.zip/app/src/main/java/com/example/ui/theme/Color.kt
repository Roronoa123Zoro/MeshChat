package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Material You Expressive Light Palette
val M3LightPrimary = Color(0xFF00658F)
val M3LightOnPrimary = Color(0xFFFFFFFF)
val M3LightPrimaryContainer = Color(0xFFC8E6FF)
val M3LightOnPrimaryContainer = Color(0xFF001E2E)

val M3LightSecondary = Color(0xFF006B56)
val M3LightOnSecondary = Color(0xFFFFFFFF)
val M3LightSecondaryContainer = Color(0xFF89F8C7)
val M3LightOnSecondaryContainer = Color(0xFF002118)

val M3LightTertiary = Color(0xFF6B4EA2)
val M3LightOnTertiary = Color(0xFFFFFFFF)
val M3LightTertiaryContainer = Color(0xFFEADDFF)
val M3LightOnTertiaryContainer = Color(0xFF24005A)

val M3LightBackground = Color(0xFFF6F9FF)
val M3LightSurface = Color(0xFFF6F9FF)
val M3LightSurfaceContainer = Color(0xFFE2E8F0)
val M3LightSurfaceContainerHigh = Color(0xFFCBD5E1)

// Material You Expressive Dark Palette (Tech Deep Dark Canvas)
val M3DarkPrimary = Color(0xFF80D4FF)
val M3DarkOnPrimary = Color(0xFF00344C)
val M3DarkPrimaryContainer = Color(0xFF004C6D)
val M3DarkOnPrimaryContainer = Color(0xFFC8E6FF)

val M3DarkSecondary = Color(0xFF6CDBAC)
val M3DarkOnSecondary = Color(0xFF00382C)
val M3DarkSecondaryContainer = Color(0xFF005139)
val M3DarkOnSecondaryContainer = Color(0xFF89F8C7)

val M3DarkTertiary = Color(0xFFD0BCFF)
val M3DarkOnTertiary = Color(0xFF3B1E6F)
val M3DarkTertiaryContainer = Color(0xFF4F378B)
val M3DarkOnTertiaryContainer = Color(0xFFEADDFF)

val M3DarkBackground = Color(0xFF0B0F17)
val M3DarkSurface = Color(0xFF0F141E)
val M3DarkSurfaceContainerLowest = Color(0xFF070A10)
val M3DarkSurfaceContainerLow = Color(0xFF131A27)
val M3DarkSurfaceContainer = Color(0xFF182030)
val M3DarkSurfaceContainerHigh = Color(0xFF212B3E)
val M3DarkSurfaceContainerHighest = Color(0xFF2B374E)

val M3DarkOnSurface = Color(0xFFE2E8F0)
val M3DarkOnSurfaceVariant = Color(0xFF94A3B8)
val M3DarkOutline = Color(0xFF475569)
val M3DarkOutlineVariant = Color(0xFF2E394E)

// Legacy aliases for backward compatibility
val MeshPrimary = M3DarkPrimary
val MeshSecondary = M3DarkSecondary
val MeshTertiary = M3DarkTertiary
val MeshBackgroundDark = M3DarkBackground
val MeshSurfaceDark = M3DarkSurface
val MeshSurfaceVariant = M3DarkSurfaceContainerHigh


