package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.ChatThreadEntity
import com.example.data.db.PeerEntity
import com.example.ui.components.PermissionHandlerCard
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatListScreen(
    threads: List<ChatThreadEntity>,
    peers: List<PeerEntity> = emptyList(),
    isDiscovering: Boolean = false,
    useSimulator: Boolean,
    onThreadSelected: (String) -> Unit,
    onDeleteThreads: (Set<String>) -> Unit = {},
    onPinThreads: (Set<String>) -> Unit = {},
    onSaveAsPdf: (Set<String>) -> Unit = {},
    onStartDiscovery: () -> Unit = {},
    onConnectPeer: (PeerEntity) -> Unit = {},
    onNavigateToRadar: () -> Unit,
    onNavigateToNetwork: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onSendSos: () -> Unit = {}
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedThreadIds by remember { mutableStateOf(setOf<String>()) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showDiscoverDialog by remember { mutableStateOf(false) }

    val isSelectionMode = selectedThreadIds.isNotEmpty()

    val filteredThreads = remember(threads, searchQuery) {
        if (searchQuery.isBlank()) {
            threads
        } else {
            val q = searchQuery.trim().lowercase()
            threads.filter { thread ->
                thread.title.lowercase().contains(q) ||
                thread.lastMessageText.lowercase().contains(q) ||
                thread.peerId.lowercase().contains(q)
            }
        }
    }

    // Confirmation AlertDialog before batch deletion
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = {
                Text(
                    text = "Delete ${selectedThreadIds.size} ${if (selectedThreadIds.size == 1) "Chat" else "Chats"}?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = "This will permanently remove the selected chat ${if (selectedThreadIds.size == 1) "thread" else "threads"} and all associated message history.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteThreads(selectedThreadIds)
                        selectedThreadIds = emptySet()
                        showDeleteDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog for Discovering Devices
    if (showDiscoverDialog) {
        AlertDialog(
            onDismissRequest = { showDiscoverDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.BluetoothSearching,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "Discover Nearby Devices",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isDiscovering) "Scanning for Bluetooth devices..." else "Found ${peers.size} nearby device(s)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (isDiscovering) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (peers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isDiscovering) "Searching for nearby Bluetooth signals..." else "No devices found nearby.\nTap 'Scan Again' to search.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.outline,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 280.dp)
                        ) {
                            items(peers, key = { it.peerId }) { peer ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                    onClick = {
                                        showDiscoverDialog = false
                                        onConnectPeer(peer)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("peer_item_${peer.peerId}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val avatarColor = try {
                                            Color(android.graphics.Color.parseColor(peer.avatarColorHex))
                                        } catch (e: Exception) {
                                            MaterialTheme.colorScheme.primary
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .background(avatarColor, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = peer.name.take(1).uppercase(),
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = peer.name,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${peer.statusMessage} • MAC: ${peer.peerId}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Button(
                                            onClick = {
                                                showDiscoverDialog = false
                                                onConnectPeer(peer)
                                            },
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(16.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text("Connect", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { onStartDiscovery() },
                    modifier = Modifier.testTag("rescan_devices_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Scan Again")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDiscoverDialog = false }
                ) {
                    Text("Close")
                }
            }
        )
    }

    Scaffold(
        floatingActionButton = {
            if (!isSelectionMode) {
                Column(horizontalAlignment = Alignment.End) {
                    // Discover Devices FAB (placed at the position of emergency icon)
                    ExtendedFloatingActionButton(
                        onClick = {
                            showDiscoverDialog = true
                            onStartDiscovery()
                        },
                        icon = {
                            if (isDiscovering) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Default.BluetoothSearching, contentDescription = "Discover Devices")
                            }
                        },
                        text = { Text("Discover Devices") },
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier
                            .padding(bottom = 8.dp)
                            .testTag("discover_devices_button")
                    )

                    // Scan Radar FAB
                    ExtendedFloatingActionButton(
                        onClick = onNavigateToRadar,
                        icon = { Icon(Icons.Default.Radar, contentDescription = null) },
                        text = { Text("Mesh Radar") },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("scan_radar_fab")
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // Contextual Top Selection Bar OR Search Bar
            if (isSelectionMode) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { selectedThreadIds = emptySet() },
                                modifier = Modifier.testTag("clear_selection_button")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Clear Selection")
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${selectedThreadIds.size} Selected",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Select All / Deselect All Button
                            TextButton(
                                onClick = {
                                    if (selectedThreadIds.size == filteredThreads.size) {
                                        selectedThreadIds = emptySet()
                                    } else {
                                        selectedThreadIds = filteredThreads.map { it.threadId }.toSet()
                                    }
                                },
                                modifier = Modifier.testTag("select_all_button")
                            ) {
                                Text(
                                    text = if (selectedThreadIds.size == filteredThreads.size) "Deselect All" else "Select All",
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Delete Button
                            IconButton(
                                onClick = { showDeleteDialog = true },
                                modifier = Modifier.testTag("delete_selected_button")
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete Selected Chats",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }

                            // Kebab Menu (MoreVert) for Pin Chat & Save as PDF
                            Box {
                                var menuExpanded by remember { mutableStateOf(false) }

                                IconButton(
                                    onClick = { menuExpanded = true },
                                    modifier = Modifier.testTag("kebab_menu_button")
                                ) {
                                    Icon(
                                        Icons.Default.MoreVert,
                                        contentDescription = "More Options",
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                DropdownMenu(
                                    expanded = menuExpanded,
                                    onDismissRequest = { menuExpanded = false },
                                    modifier = Modifier.testTag("kebab_dropdown_menu")
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Pin Chat") },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Default.PushPin,
                                                contentDescription = "Pin Chat"
                                            )
                                        },
                                        onClick = {
                                            menuExpanded = false
                                            onPinThreads(selectedThreadIds)
                                            selectedThreadIds = emptySet()
                                        },
                                        modifier = Modifier.testTag("pin_chat_menu_item")
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Save as PDF") },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Default.PictureAsPdf,
                                                contentDescription = "Save as PDF"
                                            )
                                        },
                                        onClick = {
                                            menuExpanded = false
                                            onSaveAsPdf(selectedThreadIds)
                                            selectedThreadIds = emptySet()
                                        },
                                        modifier = Modifier.testTag("save_as_pdf_menu_item")
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Permission Card check
                PermissionHandlerCard(modifier = Modifier.padding(vertical = 4.dp))

                // Search Bar for Threads & Message History
                if (threads.isNotEmpty()) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search chats or message history...", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("thread_search_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = Color.Transparent
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isSelectionMode) {
                        "SELECT CHATS TO DELETE"
                    } else if (searchQuery.isBlank()) {
                        "ACTIVE CHAT THREADS"
                    } else {
                        "SEARCH RESULTS (${filteredThreads.size})"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    color = MaterialTheme.colorScheme.primary
                )

                if (!isSelectionMode && filteredThreads.isNotEmpty()) {
                    Text(
                        text = "Long-press to select",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (threads.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Nearby Mesh Threads Yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Tap 'Mesh Radar' to discover nearby devices wirelessly.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else if (filteredThreads.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No matching chats found",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No threads or preview messages match '$searchQuery'",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        TextButton(onClick = { searchQuery = "" }) {
                            Text("Clear Search")
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .padding(top = 4.dp)
                ) {
                    items(filteredThreads, key = { it.threadId }) { thread ->
                        val isSelected = selectedThreadIds.contains(thread.threadId)
                        ThreadItemCard(
                            thread = thread,
                            searchQuery = searchQuery,
                            isSelected = isSelected,
                            isSelectionMode = isSelectionMode,
                            onLongClick = {
                                selectedThreadIds = if (isSelected) {
                                    selectedThreadIds - thread.threadId
                                } else {
                                    selectedThreadIds + thread.threadId
                                }
                            },
                            onClick = {
                                if (isSelectionMode) {
                                    selectedThreadIds = if (isSelected) {
                                        selectedThreadIds - thread.threadId
                                    } else {
                                        selectedThreadIds + thread.threadId
                                    }
                                } else {
                                    onThreadSelected(thread.threadId)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ThreadItemCard(
    thread: ChatThreadEntity,
    searchQuery: String = "",
    isSelected: Boolean = false,
    isSelectionMode: Boolean = false,
    onLongClick: () -> Unit = {},
    onClick: () -> Unit
) {
    val avatarColor = remember(thread.avatarColorHex) {
        try {
            Color(android.graphics.Color.parseColor(thread.avatarColorHex))
        } catch (e: Exception) {
            Color(0xFF3B82F6)
        }
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            } else if (thread.isBroadcastThread) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
            } else {
                MaterialTheme.colorScheme.surfaceContainer
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("thread_card_${thread.threadId}")
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSelectionMode) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onClick() },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }

            // Avatar Circle
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primary
                        else if (thread.isBroadcastThread) Color(0xFFEF4444)
                        else avatarColor
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        Icons.Default.Check,
                        contentDescription = "Selected",
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text(
                        text = if (thread.isBroadcastThread) "🚨" else thread.title.take(1).uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val annotatedTitle = buildHighlightedAnnotatedString(
                        text = thread.title,
                        query = searchQuery,
                        highlightBg = Color(0xFFFFD54F),
                        highlightText = Color(0xFF0F172A)
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (thread.isPinned) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "Pinned Chat",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .size(16.dp)
                            )
                        }
                        Text(
                            text = annotatedTitle,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (thread.isBroadcastThread) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = formatTime(thread.lastMessageTimestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val lastText = thread.lastMessageText.ifEmpty { "No messages yet" }
                    val annotatedLastText = buildHighlightedAnnotatedString(
                        text = lastText,
                        query = searchQuery,
                        highlightBg = Color(0xFFFFD54F),
                        highlightText = Color(0xFF0F172A)
                    )
                    Text(
                        text = annotatedLastText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (thread.unreadCount > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Badge(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ) {
                            Text("${thread.unreadCount}")
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
