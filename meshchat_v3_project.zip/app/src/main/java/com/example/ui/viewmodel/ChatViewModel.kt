package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MeshServiceLocator
import com.example.data.local.MessageEntity
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

/**
 * ViewModel managing active chat messages, sending text, files, and canvas sketches,
 * and exposing reactive transfer progress updates for UI rendering.
 */
class ChatViewModel @JvmOverloads constructor(
    application: Application,
    private val chatRepository: ChatRepository = MeshServiceLocator.getChatRepository(application)
) : AndroidViewModel(application) {

    private val _selectedPeerId = MutableStateFlow<String?>(null)
    val selectedPeerId: StateFlow<String?> = _selectedPeerId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val chatMessages: StateFlow<List<MessageEntity>> = _selectedPeerId
        .flatMapLatest { peerId ->
            if (peerId != null) {
                chatRepository.getMessagesForPeer(peerId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun selectPeer(peerId: String) {
        _selectedPeerId.value = peerId
    }

    fun getMessagesForPeer(peerId: String): Flow<List<MessageEntity>> {
        return chatRepository.getMessagesForPeer(peerId)
    }

    fun sendTextMessage(peerId: String, text: String, messageType: String = "TEXT") {
        if (text.isBlank()) return
        viewModelScope.launch {
            chatRepository.sendTextMessage(peerId, text, messageType)
        }
    }

    fun sendFile(peerId: String, file: File) {
        viewModelScope.launch {
            chatRepository.sendFile(peerId, file)
        }
    }

    fun sendCanvasSketch(peerId: String, imageFile: File) {
        viewModelScope.launch {
            chatRepository.sendCanvasSketch(peerId, imageFile)
        }
    }
}
