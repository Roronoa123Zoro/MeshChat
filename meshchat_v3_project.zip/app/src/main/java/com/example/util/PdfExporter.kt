package com.example.util

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Environment
import com.example.data.db.ChatThreadEntity
import com.example.data.db.MessageEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExporter {

    fun exportChatToPdf(
        context: Context,
        thread: ChatThreadEntity,
        messages: List<MessageEntity>
    ): File? {
        try {
            val pdfDocument = PdfDocument()
            val pageWidth = 595 // A4 width in points (8.27 in * 72)
            val pageHeight = 842 // A4 height in points (11.69 in * 72)
            var pageNumber = 1

            var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val subtitlePaint = Paint().apply {
                color = Color.parseColor("#64748B")
                textSize = 10f
                typeface = Typeface.DEFAULT
                isAntiAlias = true
            }

            val headerPaint = Paint().apply {
                color = Color.parseColor("#0284C7")
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val bodyPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 10f
                typeface = Typeface.DEFAULT
                isAntiAlias = true
            }

            val metaPaint = Paint().apply {
                color = Color.parseColor("#475569")
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val linePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                strokeWidth = 1f
            }

            val outgoingBubblePaint = Paint().apply {
                color = Color.parseColor("#E0F2FE")
            }

            val incomingBubblePaint = Paint().apply {
                color = Color.parseColor("#F1F5F9")
            }

            var yPosition = 40f
            val marginHorizontal = 36f
            val contentWidth = pageWidth - (marginHorizontal * 2)

            fun checkAndCreateNewPageIfNeeded(requiredHeight: Float) {
                if (yPosition + requiredHeight > pageHeight - 40f) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    yPosition = 40f

                    // Header on continuation pages
                    canvas.drawText("${thread.title} - Page $pageNumber", marginHorizontal, yPosition, subtitlePaint)
                    yPosition += 15f
                    canvas.drawLine(marginHorizontal, yPosition, pageWidth - marginHorizontal, yPosition, linePaint)
                    yPosition += 20f
                }
            }

            // Draw Top Brand Header
            canvas.drawText("MeshChat — Wireless Offline Mesh Network Export", marginHorizontal, yPosition, headerPaint)
            yPosition += 22f
            canvas.drawText("Chat Thread: ${thread.title}", marginHorizontal, yPosition, titlePaint)
            yPosition += 16f

            val dateFormat = SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
            val exportTime = dateFormat.format(Date())
            canvas.drawText("Peer ID: ${thread.peerId}  |  Exported: $exportTime  |  Total Messages: ${messages.size}", marginHorizontal, yPosition, subtitlePaint)
            yPosition += 15f

            canvas.drawLine(marginHorizontal, yPosition, pageWidth - marginHorizontal, yPosition, linePaint)
            yPosition += 20f

            if (messages.isEmpty()) {
                canvas.drawText("No messages recorded in this chat thread.", marginHorizontal, yPosition, bodyPaint)
            } else {
                for (msg in messages) {
                    val timeStr = dateFormat.format(Date(msg.timestamp))
                    val senderStr = if (msg.isOutgoing) "You (Local Node)" else msg.senderName
                    val headerText = "$senderStr   [$timeStr]"

                    val rawContent = msg.content.ifEmpty { "Attachment / Media Content" }
                    val messageLines = wrapText(rawContent, bodyPaint, contentWidth - 24f)
                    val cardHeight = (messageLines.size * 14f) + 28f

                    checkAndCreateNewPageIfNeeded(cardHeight + 10f)

                    // Card bubble
                    val bubblePaint = if (msg.isOutgoing) outgoingBubblePaint else incomingBubblePaint
                    canvas.drawRoundRect(
                        marginHorizontal,
                        yPosition,
                        pageWidth - marginHorizontal,
                        yPosition + cardHeight,
                        8f,
                        8f,
                        bubblePaint
                    )

                    var msgY = yPosition + 16f
                    canvas.drawText(headerText, marginHorizontal + 12f, msgY, metaPaint)
                    msgY += 16f

                    for (line in messageLines) {
                        canvas.drawText(line, marginHorizontal + 12f, msgY, bodyPaint)
                        msgY += 14f
                    }

                    yPosition += cardHeight + 10f
                }
            }

            pdfDocument.finishPage(page)

            // Save PDF into Download/MeshChat folder
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val meshChatDir = File(downloadsDir, "MeshChat")
            if (!meshChatDir.exists()) {
                meshChatDir.mkdirs()
            }

            val sanitizedTitle = thread.title.replace(Regex("[^a-zA-Z0-9_]"), "_")
            val fileName = "Chat_${sanitizedTitle}_${System.currentTimeMillis()}.pdf"
            val file = File(meshChatDir, fileName)

            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDocument.close()

            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val lines = mutableListOf<String>()
        val words = text.split(Regex("\\s+"))
        var currentLine = StringBuilder()

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                if (currentLine.isNotEmpty()) currentLine.append(" ")
                currentLine.append(word)
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine.toString())
                }
                currentLine = StringBuilder(word)
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine.toString())
        }
        if (lines.isEmpty()) {
            lines.add("")
        }
        return lines
    }
}
