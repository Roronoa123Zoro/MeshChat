package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object FileUtil {

    private const val TAG = "FileUtil"

    fun getMeshChatDownloadDir(): File {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val meshChatDir = File(downloadsDir, "MeshChat")
        if (!meshChatDir.exists()) {
            meshChatDir.mkdirs()
        }
        return meshChatDir
    }

    fun copyUriToDownloads(context: Context, uri: Uri, customFileName: String? = null): File? {
        return try {
            val fileName = customFileName ?: getFileNameFromUri(context, uri)
            val destFile = File(getMeshChatDownloadDir(), fileName)

            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(destFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            Log.d(TAG, "Successfully copied file to Downloads/MeshChat/${destFile.name}")
            destFile
        } catch (e: Exception) {
            Log.e(TAG, "Error copying file to Downloads: ${e.message}", e)
            null
        }
    }

    fun saveBytesToDownloads(bytes: ByteArray, fileName: String): File? {
        return try {
            val destFile = File(getMeshChatDownloadDir(), fileName)
            FileOutputStream(destFile).use { outputStream ->
                outputStream.write(bytes)
            }
            Log.d(TAG, "Successfully saved bytes to Downloads/MeshChat/${destFile.name}")
            destFile
        } catch (e: Exception) {
            Log.e(TAG, "Error saving bytes to Downloads: ${e.message}", e)
            null
        }
    }

    fun getFileNameFromUri(context: Context, uri: Uri): String {
        var fileName = "mesh_file_${System.currentTimeMillis()}"
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIdx != -1) {
                    val queriedName = cursor.getString(nameIdx)
                    if (!queriedName.isNullOrBlank()) fileName = queriedName
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying file name: ${e.message}")
        }
        return fileName
    }

    fun getMimeTypeFromFileName(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            // Images
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "bmp" -> "image/bmp"
            "svg" -> "image/svg+xml"
            // Documents
            "pdf" -> "application/pdf"
            "txt", "log" -> "text/plain"
            "json" -> "application/json"
            "html", "htm" -> "text/html"
            "csv" -> "text/csv"
            "doc", "docx" -> "application/msword"
            "xls", "xlsx" -> "application/vnd.ms-excel"
            "ppt", "pptx" -> "application/vnd.ms-powerpoint"
            "apk" -> "application/vnd.android.package-archive"
            // Audio (Songs)
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "opus", "ogg" -> "audio/ogg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            "aac" -> "audio/aac"
            // Video
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "mov" -> "video/quicktime"
            "3gp" -> "video/3gpp"
            "webm" -> "video/webm"
            // Archives
            "zip" -> "application/zip"
            "rar" -> "application/vnd.rar"
            "7z" -> "application/x-7z-compressed"
            else -> "*/*"
        }
    }

    fun openFileInSystemApp(context: Context, uriString: String?, mimeType: String, fileName: String): Boolean {
        if (uriString.isNullOrBlank()) {
            Toast.makeText(context, "Cannot open: file path is empty", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val uri = if (uriString.startsWith("content://")) {
                Uri.parse(uriString)
            } else if (uriString.startsWith("file://") || uriString.startsWith("/")) {
                val rawPath = uriString.removePrefix("file://")
                val file = File(rawPath)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                } else {
                    Uri.fromFile(file)
                }
            } else {
                Uri.parse(uriString)
            }

            val resolvedMime = if (mimeType.isNotBlank() && mimeType != "*/*") {
                mimeType
            } else {
                getMimeTypeFromFileName(fileName)
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Open $fileName with...")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error launching open intent for $fileName: ${e.message}", e)
            Toast.makeText(context, "No app found to view $fileName. (${e.localizedMessage})", Toast.LENGTH_LONG).show()
            false
        }
    }
}
