package com.example.system

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import com.example.MainActivity

/**
 * Helper class for creating high-priority heads-up chat notifications when a message
 * is received while the application is in the background or screen is locked.
 */
class ChatNotificationHelper(private val context: Context) {

    companion object {
        private const val TAG = "ChatNotificationHelper"
        const val CHANNEL_ID = "chat_messages_channel"
        const val CHANNEL_NAME = "Chat Messages"
        const val EXTRA_PEER_ID = "EXTRA_PEER_ID"
    }

    private val notificationManager: NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Offline MeshChat incoming messages and alerts"
                enableVibration(true)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(channel)
            Log.d(TAG, "Notification channel $CHANNEL_ID created with HIGH importance.")
        }
    }

    /**
     * Post a rich heads-up notification for an incoming chat message or alert.
     */
    fun showIncomingMessageNotification(
        senderId: String,
        senderName: String,
        messageText: String,
        messageType: String
    ) {
        val displayContent = when (messageType.uppercase()) {
            "SKETCH", "CANVAS", "CANVAS_SKETCH" -> "🎨 Sent a Canvas Sketch"
            "FILE" -> if (messageText.isNotBlank()) "📁 Sent a File: $messageText" else "📁 Sent a File"
            "LOCATION" -> "📍 Location Ping"
            "SOS" -> if (messageText.isNotBlank()) "🚨 SOS Broadcast: $messageText" else "🚨 SOS Broadcast"
            else -> messageText
        }

        // Deep link intent to launch MainActivity with target peer ID
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_PEER_ID, senderId)
        }

        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            senderId.hashCode(),
            intent,
            pendingIntentFlags
        )

        val person = Person.Builder()
            .setName(senderName)
            .setKey(senderId)
            .build()

        val messagingStyle = NotificationCompat.MessagingStyle(person)
            .addMessage(displayContent, System.currentTimeMillis(), person)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setStyle(messagingStyle)
            .setContentTitle(senderName)
            .setContentText(displayContent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationId = (senderId + messageType).hashCode()
        try {
            notificationManager.notify(notificationId, notification)
            Log.d(TAG, "Notification posted for peer $senderName ($senderId), type=$messageType")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to post notification for $senderName: ${e.message}", e)
        }
    }
}
